
<div class="row" style="text-align: center">
    <div class="col s12 m6">
      <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Στοιχεία Επικοινωνίας με Ο.ΣΥ. Α.Ε.</span>
            <p>Μετσόβου 15,Αθήνα 106 82</p>
            <p>Τηλ.:210-82.00.999	</p>
            <p>Φαξ:210-82.12.219</p>
            <p>e-mail : oasa@oasa.gr</p>
            <p>Τηλεφωνική Πληροφόρηση:11 185</p>
          </div>
      </div>
    </div>
  

    <div class="col s12 m6">
      <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Στοιχεία Επικοινωνίας με Ο.ΣΥ. Α.Ε.</span>
          <p>Παρνασσού 6, Αγ. Ιωάννης Ρέντης, Τ.Κ. 182 33</p>
          <p>Τηλεφωνικό Κέντρο: 210 4270796</p>
          <p> email*: osy@osy.gr </p>
        </div>
      </div>
    </div>
  

    <div class="col s12 m6">
      <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Στοιχεία Επικοινωνίας με ΣΤΑ.ΣΥ. Α.Ε.</span>
          <p>Αθηνάς 67, 105 52, Αθήνα </p>  
          <p>Ωράριο λειτουργίας: Δευτέρα έως Παρασκευή, 08:00 - 16:00</p>
          <p>Τηλέφωνο  :214.414.6400</p>    
        </div>
    </div>

  </div>

