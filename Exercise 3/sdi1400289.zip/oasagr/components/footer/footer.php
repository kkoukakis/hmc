
<footer style="height: 5px;">
<?php

//INSERT LAST NEWS with sql
echo "<p href=\"news.php\" style= 'padding-top:11%; text-align: center; font-weight: bold;'>News</p> <br>";

if($test === true){
echo '<pre>';
var_dump($_SESSION);
echo '</pre>';
}
?>
</footer>
</html>