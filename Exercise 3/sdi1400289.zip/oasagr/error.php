<script>alert('Σφάλμα! επιστροφή στην αρχική');</script>
<?php
header('location: index.php');
?>