<?php 
//HEADER
include('./components/header/header.php');
?>


<?php
// BREADCRUMB
$breadcrumb = array('Oasa.gr','Νέα');
$breadlinks = array('index.php','news.php');
include('components\breadcrumbs\breadcrumb.php');
?>




<ul class="collection" style="background-color: whitesmoke;">


<?php 


echo('<li class="collection-item"><a>14.01.20 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 101 λόγω έργων στο Δήμο Αλίμου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>');

?>
<li class="collection-item"><a>14.01.20 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 101 λόγω έργων στο Δήμο Αλίμου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>
<li class="collection-item"><a>14.01.20 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 162 στο Δήμο Βάρης – Βούλας – Βουλιαγμένης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.01.20 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.12.19 Λειτουργία ΜΜΜ την Παραμονή Πρωτοχρονιάς 31-12-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.12.19 Μεταβολές λεωφορειακών γραμμών λόγω έντονων καιρικών φαινομένων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.12.19 Λειτουργία των Λεωφορειακών Γραμμών 242, 250 και Ε90.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.12.19 Λειτουργία ΜΜΜ κατά την εορταστική περίοδο Χριστουγέννων - Πρωτοχρονιάς 2019-2020. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.12.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 725, 726 και Α10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.12.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 700, 747, Α11 και Β11. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.12.19 Παράταση της μερικής προσωρινής τροποποίησης της λεωφορειακής  γραμμής 324  λόγω έργων στο Δήμο Παλλήνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.12.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 117 και 122 στο Δήμο Βάρης – Βούλας – Βουλιαγμένης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.12.19    Λειτουργία Μέσων Σταθερής Τροχιάς την Τρίτη 17 Δεκεμβρίου 2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.12.19 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών 807 και 809, λόγω εργασιών στην οδό Ηπείρου στο Δήμο Κορυδαλλού. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.12.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891, λόγω διεξαγωγής αγώνα στο Δημοτικό Στάδιο Περιστεριού. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891 λόγω έργων στο Δήμο Αιγάλεω </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 537, 721, 734 και 755. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.19 Λειτουργία ΜΜΜ την Κυριακή 15-12-2019 λόγω της διεξαγωγής του 6ου αγώνα δρόμου «SANTA RUN ATHENS» στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.12.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 813  λόγω εορταστικών εκδηλώσεων στον Ι.Ν. Αγ. Σπυρίδωνα, στο Δήμο Αιγάλεω </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.12.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 021 και 046 λόγω εορταστικών εκδηλώσεων στον Ι.Ν. Αγ. Ελευθερίου, στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891, λόγω αγώνα. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 731 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 712, 723, 733, 749 και Β12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.12.19 Λειτουργία των ΜΜΜ κατά την διάρκεια των κυκλοφοριακών ρυθμίσεων της ΕΛ.ΑΣ. την Παρασκευή 6-12-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.12.19 Προσωρινή διακοπή των δρομολογίων των λεωφορειακών γραμμών 822, 823 και 892, στο Δήμο Περιστερίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.12.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 128 στο Δήμο Γλυφάδας λόγω εορταστικών εκδηλώσεων . </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.12.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 818 στον Δήμο Περάματος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.12.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 830, 837, 891 - 892 λόγω εορταστικών εκδηλώσεων στο Δήμο Αγ. Βαρβάρας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.12.19 Παράταση της Μερικής Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 302 λόγω έργων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.11.19 Προσωρινή παύση των δρομολογίων της λεωφορειακής γραμμής 823, στο Δήμο Περιστερίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.11.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 407. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.11.19 Μερική τροποποίηση των λεωφορειακών γραμμών Α1,Β1,130,049,217,229,218,915,500 (νυχτερινή) λόγω εργασιών στο Δήμο Πειραιά  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>25.11.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 809 και 810 λόγω εορταστικών εκδηλώσεων στον Ι.Ν. Αγ. Στυλιανού στις  οδούς Καραολή  - Δημητρίου (από Παπαδιαμάντη έως Ποταμού) στο Δήμο Κορυδαλλο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.11.19 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 642,  λόγω εργασιών στο Δήμο Ηρακλείου Αττικής. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.11.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 306 λόγω έργων κατασκευής αγωγών φυσικού αερίου στο Δήμο Παλλήνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.11.19 Προσωρινή διακοπή των δρομολογίων στο τμήμα ΕΙΡΗΝΗ–ΚΗΦΙΣΙΑ της γραμμής 1 του Μετρό, λόγω εργασιών στο σταθμό Κηφισιά, την Κυριακή 17-11-2019  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.11.19 Λειτουργία ΜΜΜ λόγω των εκδηλώσεων εορτασμού της 46ης επετείου του Πολυτεχνείου από τις 14-11-2019 έως τις 18-11-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.11.19 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής Β5 λόγω έργων επί της οδού Τόμπρα στο Δήμο Αγ. Παρασκευής. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.11.19 Παράταση μερικής προσωρινής τροποποίηση της λεωφορειακής γραμμής 307 λόγω έργων  κατασκευής δικτύου αποχέτευσης στο Δήμο Παιανίας-Γλ. Νερών. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.11.19 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 324  λόγω έργων στο Δήμο Παλλήνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.19 Λειτουργία ΜΜΜ λόγω της διεξαγωγής του 37ου Αυθεντικού Μαραθωνίου Αθηνών και των παράλληλων αγώνων δρόμου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.19 Νέα μερική προσωρινή τροποποίησης της γραμμής τρόλεϊ 17 λόγω έργων στην οδό Ελ. Βενιζέλου του Δήμου Δραπετσώνας-Κερατσινίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.11.19 Ενημέρωση Μαθητών Πρωτοβάθμιας και Δευτεροβάθμιας εκπαίδευσης  της Περιφέρειας Αττικής για την  ανανέωση του δικαιώματος ελεύθερης  μετακίνησης με τα ΜΜΜ του ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.11.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 809, 810, 827, 830, 846 και 847, λόγω εργασιών στην οδό Βαλαωρίτου, στο  Δήμο Πειραιά. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.11.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 810, λόγω εργασιών στην οδό Ζωοδόχου Πηγής, στο Δήμο Νίκαιας-Α.Ι.Ρέντη. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.11.19 Παράταση της Μερικής Προσωρινής Τροποποίησης της Λεωφορειακής  Γραμμής 302  λόγω έργων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>31.10.19 Ενοποίηση της Λεωφορειακής Γραμμής 322 με τη Λεωφορειακή Γραμμή 323 στο Δήμο Σπατών-Αρτέμιδος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.19 Μερική τροποποίηση της διαδρομής των λεωφορειακών  γραμμών 036, 046 και 653 στις 25 και 26-10-2019,  λόγω εκδηλώσεων στον Ι.Ν. Αγ. Δημητρίου στην οδό Πανόρμου στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.19 Προσωρινές τροποποιήσεις της διαδρομής λεωφορειακών γραμμών, γραμμών τρόλεϊ και τραμ λό-γω των εορταστικών εκδηλώσεων για την Εθνική Επέτειο της 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.10.19 Λειτουργία ΜΜΜ την Τετάρτη 23 Οκτωβρίου 2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.10.19  Μερική προσωρινή τροποποίηση της διαδρομής  των λεωφορειακών  γραμμών  322, 323 και 305  λόγω ασφαλτόστρωσης στην οδό Αριστοφάνους στην Αρτέμιδα,  του Δήμου Σπάτων - Αρτέμιδος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 806, 814, 824, 825 και 852, λόγω έργων στην οδό Βουρνόβα,  του Δήμου Νίκαιας-Α.Ι. Ρέντη. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 040,  910 και των γραμμών τρόλεϊ 1, 5 και 10 λόγω της διοργάνωσης του 4ου νυχτερινού αγώνα δρόμου «Kallitheanightrun 2019» στο Δήμο Καλλιθέας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 227 και της γραμμής τρόλεϊ 4 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>




<li class="collection-item"><a>15.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 120, 309 και 330 στο Δήμο Κρωπίας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.10.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 730. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.10.19 Παράταση προσωρινής τροποποίησης της γραμμής τρόλεϊ 17 και της λεωφορειακής γραμμής 848 λόγω εργασιών στην οδό Ελ. Βενιζέλου του Δήμου Δραπετσώνας-Κερατσινίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.10.19 Υπενθύμιση για την ανανέωση δικαιώματος μετακίνησης με μειωμένο κόμιστρο για τους φοιτητές με την έναρξη κάθε νέου ακαδημαϊκού έτους. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 306 και 307 λόγω διεξαγωγής του αγώνα δρόμου PLATON RUN.   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 203, 204 και 212 λόγω διεξαγωγής αθλητικών αγώνων στο Δήμο Βύρωνα. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.19 Μερική προσωρινή τροποποίηση των λεωφορειακών. γραμμών 130, 136 και 219 λόγω αθλητικής διοργάνωσης «Αγώνες Ιστορικής Μνήμης-Νέα Σμύρνη 2019» στο Δήμο Νέας Σμύρνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.19 Μερική Προσωρινή Τροποποίηση της Λεωφορειακής  Γραμμής 302  λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.19 Λειτουργία Μέσων Σταθερής Τροχιάς την Πέμπτη 3 Οκτωβρίου 2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.19 Έκτακτη Ενημέρωση για τη Λειτουργία  Λεωφορειακών γραμμών και γραμμών Τρόλεϊ την Τετάρτη 2 Οκτωβρίου 2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.10.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 527. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.10.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 822. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.10.19 Λειτουργία  των ΜΜΜ την Τετάρτη 2 Οκτωβρίου 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.09.19 Αποκαταστάθηκε η κυκλοφορία στην γραμμή 1 της ΣΤΑ.ΣΥ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.09.19 Έκτακτη δρομολόγηση λεωφορειακής γραμμής  λόγω  εκτροχιασμού συρμού της γραμμής 1 της ΣΤΑΣΥ, στην Κηφισιά. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.19 Μερική προσωρινή τροποποίηση των τροποποιημένων λεωφορειακών  γραμμών 807 και 809, λόγω εργασιών στην οδό Ηπείρου του Δήμου Κορυδαλλού. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 859 λόγω εκδηλώσεων  στον Ι.Ν. Αγ. Παντελεήμονος στη Δραπετσώνα, του Δήμου Δραπετσώνας-Κερατσινίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.19 Λειτουργία ΜΜΜ την Κυριακή 29-09-2019 λόγω της συνδιοργάνωσης του «33ου Γύρου της Αθήνας» και του 11ου Συμβολικού Αγώνα Δρόμου και Περιπάτου «Greece Race for the Cure» στο Δήμο Αθήναίων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>27.09.19 Μερική Προσωρινή Τροποποίηση της Λεωφορειακής  Γραμμής 209  λόγω έργων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 060, 100, 224, 203 - 204, στο Δήμο Αθηναίων, λόγω του εορτασμού του Πολιούχου της Αθήνας Αγίου Διονυσίου του Αρεοπαγίτου.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>26.09.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.09.19 Ενημέρωση για τη λειτουργία των ΜΜΜ λόγω απεργιακών κινητοποιήσεων την Τρίτη 24 Σεπτεμβρίου 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 109  στον Δήμο Αλίμου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 915, 909 και 814,  λόγω εργασιών στην οδό Ασκληπιού του Δήμου Πειραιά. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 892. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών Α1, Β1, 130, 217, 229, 860,910 και της γραμμής τρόλεϊ 10 λόγω της διοργάνωσης του «1ου ΗΜΙΜΑΡΑΘΩΝΙΟΥ ΚΑΛΛΙΘΕΑΣ». </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.19 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 10 και της λεωφορειακής γραμμής Ε90 λόγω έργων στην οδό Ταγματάρχου Πλέσσα του Δήμου Καλλιθέας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 054 και 605, λόγω εκδηλώσεων στο Δήμο Ν. Ιωνίας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 405, 447, 411, 451, λόγω εργασιών, στο Δήμο Χαλανδρίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.09.19 Μερική Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 404, στο Δήμο Χαλανδρίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών 816 και 035 λόγω εορτασμού του Ι.Ν. Αγ. Σοφίας στη Δημοτική Κοινότητα Ταύρου στο Δήμο Μοσχάτου-Ταύρου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.09.19 Προσωρινή μεταφορά της προσωρινής αφετηρίας της λεωφορειακής γραμμής 820  του Δήμου Κερατσινίου-Δραπετσώνας λόγω εργασιών. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.09.19 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών Α1, Β1, 217, 860, Χ96, Ε90 και 130 λόγω έργων στην οδό  Ιωάννου Φιξ του Δήμου Παλαιού Φαλήρου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.09.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.09.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 861. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.09.19 Χειμερινά δρομολόγια για λεωφορεία και τρόλεϊ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.09.19 Δρομολόγια Σεπτεμβρίου Μέσων Σταθερής Τροχιάς.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.08.19 Επαναλειτουργία των Λεωφορειακών Γραμμών 242, 250 και Ε90 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.08.19 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΛΕΩΦ. ΓΡΑΜΜΩΝ ΛΟΓΩ ΕΟΡΤΑΣΤΙΚΩΝ ΕΚΔΗΛΩΣΕΩΝ ΣΤΟΝ Ι.Ν. ΑΓ. ΜΕΛΕΤΙΟΥ ΣΤΗΝ ΟΔΟ ΒΟΡΕΙΟΥ ΗΠΕΙΡΟΥ ΣΤΟ ΔΗΜΟ ΑΘΗΝΑΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>27.08.19 Μερική Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 404, στο Δήμο Χαλανδρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.08.19 Παράταση μερικής προσωρινής τροποποίησης της διαδρομής της λεωφορειακής γραμμής 507 (ΖΗΡΙΝΕΙΟ- ΡΟΔΟΠΟΛΗ – ΣΤΑΜΑΤΑ), στον Δήμο Διονύσου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.08.19 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών 847 και 852 λόγω εκδηλώσεων στον Ι.Ν. Κοίμησης της Θεοτόκου  στο Δήμο Νίκαιας- Α.Ι.Ρέντη. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.08.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 404, 421, 450, 451, 460, 461 και της γραμμής τρόλεϊ 19 λόγω έργων κατασκευής αγωγών ομβρίων υδάτων στο Δήμο Χαλανδρίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.08.19 Προσωρινή μεταφορά των αφετηριών των λεωφορειακών γραμμών 301, 302, 314, 319, 407, 411 και της στάσης της γραμμής 406 στο Σταθμό Δουκ. Πλακεντίας λόγω έργων.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.08.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 818 στον Δήμο Περάματος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.08.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 402, 411, 421, 447, 450, 451, 460, 461 και των γραμμών τρόλεϊ 10, 18, 19 λόγω έργων, στο Δήμο Χαλανδρίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.08.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών  Β9 και 541, λόγω του εορτασμού της «Μεταμόρφωσης του Σωτήρος», στο Δήμο Μεταμόρφωσης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.07.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.07.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 054 και 605. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.07.19 Παράταση Προσωρινής Τροποποίησης της Διαδρομής της Λεωφορειακής Γραμμής 730. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.07.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 402, 411, 447, 450 και 460, καθώς και των Γραμμών Τρόλλεϋ 10, 18 και 19. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.07.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 822 και 823. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.07.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής Γ10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.07.19 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 17 λόγω εργασιών στην οδό Ελ. Βενιζέλου του Δήμου Δραπετσώνας-Κερατσινίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.07.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 866 και Γ16. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>22.07.19 Θερινό πρόγραμμα δρομολογίων ΙΙ στις γραμμές Λεωφορείων και Τρόλεϊ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>12.07.19 Παράταση μερικής προσωρινής τροποποίησης της διαδρομής της λεωφορειακής γραμμής 507 (ΖΗΡΙΝΕΙΟ- ΡΟΔΟΠΟΛΗ – ΣΤΑΜΑΤΑ), στον Δήμο Διονύσου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>11.07.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 730. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.07.19 Λειτουργία των Λεωφορειακών Γραμμών 242, 250 και Ε90. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.07.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.07.19 Δρομολόγια Λεωφορείων και Τρόλεϊ κατά τη διάρκεια των εκλογών.   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.19 Προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 022 και 060 λόγω εκδηλώσεων Εορτασμού της Επετείου Διακήρυξης της Ανεξαρτησίας των Η.Π.Α. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 721 και Α10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.19 Λειτουργία ΜΜΜ την Τετάρτη 3-7-2019 λόγω προεκλογικών συγκεντρώσεων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.19 Θερινά δρομολόγια μέσων σταθερής τροχιάς (ΣΤΑ.ΣΥ.) 2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.06.19 Λειτουργία ΜΜΜ την Δευτέρα 24-6-2019 λόγω διεξαγωγής Συναυλίας στο Καλλιμάρμαρο Στάδιο στο Δήμο Αθηναίων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.06.19 Θερινά δρομολόγια για λεωφορεία και τρόλλεϋ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.06.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 705 και Γ12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.06.19 Λειτουργία ΜΜΜ την Κυριακή 23-6-2019 λόγω της διεξαγωγής του αγώνα δρόμου «SNF RUN-Τρέχοντας προς το μέλλον»  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.06.19 Παράταση μερικής προσωρινής τροποποίησης της διαδρομής της λεωφορειακής γραμμής 507 (ΖΗΡΙΝΕΙΟ- ΡΟΔΟΠΟΛΗ – ΣΤΑΜΑΤΑ), στον Δήμο Διονύσου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.06.19 Προσωρινή μεταφορά αφετηρίας των λεωφορειακών γραμμών 904 και 300 στο Δήμο Πειραιά.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.06.19 Λειτουργία των Μέσων Σταθερής Τροχιάς την Παρασκευή 14-6-2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.06.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 120, 124, 128, 140 και 205, λόγω αθλητικής εκδήλωσης στην οδό Διαδόχου Παύλου του Δήμου Γλυφάδας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.06.19 Λειτουργία ΜΜΜ τo Σάββατο 8-6-2019 λόγω της διεξαγωγής του «ATHENS PRΙDE FESTIVAL». </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.06.19 Μερική Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 054, 608 - 622 το Σάββατο - την Κυριακή 8 - 9-06-2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.06.19 Λειτουργία των Μέσων Σταθερής Τροχιάς την Δευτέρα 3-6-2019.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.05.19 Λειτουργία των Μέσων Σταθερής Τροχιάς την Παρασκευή 31-5-2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.05.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 704. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.05.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 206 στο Δήμο Ηλιούπολης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.05.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.19 Θερινά δρομολόγια για τις λεωφορειακές γραμμές Express Αεροδρομίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.19 Δρομολόγια Λεωφορείων και Τρόλεϊ κατά την περίοδο των εκλογών.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.05.19 Προσωρινή Τροποποίηση της Διαδρομής των Λεωφορειακών Γραμμών 712, 713, 723, 749 και Β12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.05.19 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 040 λόγω έργων στην οδό Χαροκόπου του Δήμου Καλλιθέας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.05.19 Προσωρινή Τροποποίηση της Διαδρομής της Λεωφορειακής Γραμμής 721. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.05.19 Παράταση μερικής προσωρινής τροποποίησης της διαδρομής της λεωφορειακής γραμμής 507 (ΖΗΡΙΝΕΙΟ- ΡΟΔΟΠΟΛΗ – ΣΤΑΜΑΤΑ), στον Δήμο Διονύσου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.05.19 Παράταση Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 704. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>10.05.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 049, 130, 217, 229, A1, B1, X96, X80 και των γραμμών τρόλεϊ 17 και 20 λόγω εκδήλωσης στην οδό 2ας Μεραρχίας και Φίλωνος – Νοταρά, στο Δήμο Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.05.19 Μερική προσωρινή τροποποίηση της διαδρομής  των λεωφορειακών  γραμμών  319, 326 και 305  λόγω έργων στην οδό Β. Παύλου, στο Δήμο Σπάτων - Αρτέμιδος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.05.19 Προσωρινή μεταφορά στάσης στο Δήμο Αγ. Παρασκευής. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.05.19 Επαναλειτουργία της Λεωφορειακής Γραμμής Χ80 Πειραιάς-Ακρόπολη-Σύνταγμα Express από την Τετάρτη 8 Μαΐου 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.04.19 Λειτουργία των ΜΜΜ την Τετάρτη 1 Μαΐου 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.19 Δρομολόγια Λεωφορείων και Τρόλεϊ (Ο.ΣΥ.) κατά τη διάρκεια των εορτών του Πάσχα 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.04.19 Δρομολόγια ΣΤΑΣΥ κατά τη διάρκεια των εορτών του Πάσχα 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.04.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 537, 721, 734, 740, 755, A10 και B10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.04.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 300 και 904 λόγω έργων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.04.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών  535 (ΖΗΡΙΝΕΙΟ – ΕΥΞΕΙΝΟΣ ΠΟΝΤΟΣ)  και 535 Α (ΖΗΡΙΝΕΙΟ – ΕΥΞΕΙΝΟΣ ΠΟΝΤΟΣ – ΦΡΑΓΜΑ – ΚΑΛΕΤΖΙ), στο Δήμο Διονύσου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.04.19 Προσωρινή μεταφορά αφετηρίας των λεωφορειακών γραμμών 904 και 300 στο Δήμο Πειραιά.   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.04.19 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 820 και της γραμμής τρόλεϊ 17 λόγω εργασιών στην οδό Καραολή Δημητρίου  του Δήμου Δραπετσώνας-Κερατσινίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.04.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.04.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 866 και Γ16. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.04.19 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 20 και των λεωφορειακών γραμμών 300 και 904 στο Δήμο Πειραιά, λόγω της αθλητικής εκδήλωσης «Σκυταλοδρομία Πειραιάς Βίκος Street Relays Piraeus 2018» το  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.04.19 Με κλειστές πύλες όλοι οι σταθμοί αρμοδιότητας του ΟΑΣΑ (γραμμές 1,2 και 3 της ΣΤΑΣΥ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.04.19 Λειτουργία ΜΜΜ την Κυριακή 14-4-2019 λόγω της διεξαγωγής του 3ου Αγώνα Πεδίου Άρεως «Στις γειτονιές της Αθήνας» και του «26ου Ποδηλατικού Γύρου Αθήνας» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.04.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 866 και Γ16 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.04.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 730. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.04.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 721 και Α10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.04.19 Μερική τροποποίηση των λεωφορειακών γραμμών 040,130,217,218,229, Α1,Β1,500,Χ96 και της γραμμής τρόλεϊ 20 λόγω νυχτερινού αγώνα δρόμου σε οδούς του Δήμου Πειραιά το Σάββατο 13-04-2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.04.19 Μερική Προσωρινή Τροποποίηση και Μεταφορά της Αφετηρίας της Λεωφορειακής Γραμμής 021 την Κυριακή 07-04-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.04.19 Λειτουργία ΜΜΜ την Τετάρτη 3 Απριλίου 2019. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.03.19 Παράταση Προσωρινής Τροποποίησης των Λεωφορειακών Γραμμών 855 και 879. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.03.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 818 λόγω εργασιών ασφαλτόστρωσης στο Δήμο Περάματος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.03.19 Παράταση Μερικής Προσωρινής Τροποποίησης της Λεωφορειακής  Γραμμής 051  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.03.19 Προσωρινές τροποποιήσεις λόγω των εκδηλώσεων εορτασμού της Εθνικής Επετείου της 25ης Μαρτίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.03.19 Παράταση Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 704. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.03.19 Διευκρινήσεις ΣΤΑΣΥ για τη δημοσιοποίηση ψευδούς είδησης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504, 725 και 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 721 και Α10. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.03.19 Λειτουργία ΜΜΜ την Κυριακή 17-3-2019 λόγω της διεξαγωγής του 8ου Ημιμαραθωνίου Δρόμου Αθηνών και των παράλληλων αγώνων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>14.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 537, 721, 734 και 755. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 446, 501 και 541, στο Δήμο Αμαρουσίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 537, 721, 734 και 755. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.03.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 712, 713, 723, 749 και Β12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.03.19 Λειτουργία ΜΜΜ την Κυριακή 10-3-2019 λόγω κυκλοφοριακών ρυθμίσεων στην Πλ. Συντάγματος </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.03.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 602 (Ν. ΙΩΝΙΑ – ΚΑΛΟΓΡΕΖΑ – Σ. ΠΑΝΟΡΜΟΥ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.03.19 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 106 και 130 λόγω έργων στο Δήμο Νέας Σμύρνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.03.19 Μερική τροποποίηση της προσωρινής λεωφορειακής γραμμής 310 «ΜΑΡΑΘΩΝΑΣ – ΝΕΑ ΜΑΚΡΗ – ΡΑΦΗΝΑ – ΜΑΤΙ – ΜΑΡΑΘΩΝΑΣ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.03.19  Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 712, 713, 723, 733, 749 και Β12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.03.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 602 (Ν. ΙΩΝΙΑ – ΚΑΛΟΓΡΕΖΑ – Σ. ΠΑΝΟΡΜΟΥ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 866 και Γ16, λόγω αποκριάτικων εκδηλώσεων στο Δήμο Ασπροπύργου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.19 Μερική Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής Α13 την Κυριακή  3-3-2019  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.19 Τροποποίηση διαδρομών των λεωφορειακών γραμμών 218, 260 και της γραμμής τρόλεϊ 1, λόγω αποκριάτικων εκδηλώσεων στο Δήμο Μοσχάτου-Ταύρου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.02.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 806, 809, 810, 830, 831 και 750 στο Δήμο Κορυδαλλού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>24.02.19 Μεταβολές Λεωφορειακών Γραμμών λόγω επικίνδυνων καιρικών φαινομένων στις 24-2-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>21.02.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 704. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.02.19 Διακοπή κυκλοφορίας των  συρμών του Τραμ στο τμήμα από τη στάση «Μπάτης» έως το Στάδιο Ειρήνης και Φιλίας (ΣΕΦ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.02.19 Μερική Προσωρινή Τροποποίηση της Λεωφ. Γραμμής 051 από 22-02-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.02.19 Μερική Προσωρινή Τροποποίηση της Λεωφ. Γραμμής Α13 την 24-2-2019 από 07:30 έως 09:30 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>08.02.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής Γ12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>05.02.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 605 ΠΕΡΙΣΣΟΣ - ΑΝΩ ΠΑΤΗΣΙΑ (ΚΥΚΛΙΚΗ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.02.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 - Πέμπτη 07.02.2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.01.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 711 και Β12. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.01.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 830 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.01.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 302 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.01.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 421 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.01.19 Μερική προσωρινή τροποποίηση της Λεωφορειακής Γραμμής 421 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.01.19 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504, 725 και 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.01.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.01.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 881. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.01.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 504. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.01.19 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.01.19 ΑΛΛΑΓΕΣ ΣΤΗ ΛΕΙΤΟΥΡΓΙΑ ΤΟΥ ΜΕΤΡΟ ΛΟΓΩ ΕΠΙΣΚΕΨΗΣ ΤΗΣ ΑΝΓΚΕΛΑ ΜΕΡΚΕΛ (10-11-01-2019) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.01.19 ΜΕΤΑΒΟΛΕΣ ΛΕΩΦΟΡΕΙΑΚΩΝ ΓΡΑΜΜΩΝ ΛΟΓΩ ΠΑΓΕΤΟΥ 9-1-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.01.19 ΜΕΤΑΒΟΛΕΣ ΛΕΩΦΟΡΕΙΑΚΩΝ ΓΡΑΜΜΩΝ ΛΟΓΩ ΧΙΟΝΟΠΤΩΣΗΣ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.01.19 ΜΕΤΑΒΟΛΕΣ ΛΕΩΦΟΡΕΙΑΚΩΝ ΓΡΑΜΜΩΝ ΛΟΓΩ ΧΙΟΝΟΠΤΩΣΗΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.12.18 Λειτουργία Μέσων Σταθερής Τροχιάς την παραμονή της Πρωτοχρονιάς 31-12-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.12.18 Λειτουργία ΜΜΜ Χριστούγεννα - Πρωτοχρονιά  2018-2019 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.18 Μερική προσωρινή τροποποίηση  της διαδρομής των  λεωφορειακών  γραμμών 117 και 122, στο Δήμο Βάρης – Βούλας – Βουλιαγμένης, λόγω διεξαγωγής αγώνα δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.12.18 Λειτουργία ΜΜΜ την Τετάρτη 12 Δεκεμβρίου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.12.18 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΤΩΝ ΛΕΩΦ. ΓΡΑΜΜΩΝ ΛΟΓΩ ΕΜΠΟΡΟΠΑΝΗΓΥΡΗΣ ΣΤΟΝ Ι.Ν. ΑΓ.ΕΛΕΥΘΕΡΙΟΥ ΓΚΥΖΗ ΣΤΙΣ ΟΔΟΥΣ ΡΑΓΚΑΒΗ – ΜΟΜΦΕΡΑΤΟΥ - ΒΑΡΒΑΚΗ ΣΤΟ ΔΗΜΟ ΑΘΗΝΑΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.12.18 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΤΗΣ ΛΕΩΦ. ΓΡΑΜΜΗΣ 813 ΛΟΓΩ ΕΜΠΟΡΟΠΑΝΗΓΥΡΕΩΣ ΓΙΑ ΤΗ ΕΟΡΤΗ ΤΟΥ ΑΓΙΟΥ ΣΠΥΡΙΔΩΝΑ ΣΤΟ ΔΗΜΟ ΑΙΓΑΛΕΩ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 705 και Γ12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 725 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.18 Λειτουργία των ΜΜΜ κατά την διάρκεια των κυκλοφοριακών ρυθμίσεων της ΕΛ. ΑΣ. λόγω των εκδηλώσεων-κινητοποιήσεων  για τη συμπλήρωση δέκα ετών από τον θανάσιμο τραυματισμό του Αλέξανδρου Γρηγορόπουλου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.18 Λειτουργία ΜΜΜ την Κυριακή 2-12-2018 λόγω της διεξαγωγής του 32ου Γύρου της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.18 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 20 λόγω εργασιών στην οδό Βασ. Παύλου του Δήμου Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 128 στο Δήμο Γλυφάδας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.18 Προσωρινή διακοπή των δρομολογίων της λεωφορειακής γραμμής  653 (ΨΥΧΙΚΟ – ΠΑΝΟΡΜΟΥ Β) την Κυριακή 2-12-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.11.18 Λειτουργία  των ΜΜΜ την Τετάρτη 28 Νοεμβρίου  2018_Ενημέρωση </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>27.11.18 Λειτουργία  των ΜΜΜ την Τετάρτη 28 Νοεμβρίου  2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.11.18 Μερική προσωρινή τροποποίηση των λεωφoρειακών γραμμών 810, 809 λόγω εορταστικής πανήγυρης του Ι.Ν. Αγ. Στυλιανού στις  οδούς Καραολή  - Δημητρίου (από Παπαδιαμάντη έως Ποταμού) του Δήμου Κορυδαλλού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.11.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 855 και 879 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.11.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 817 και 863 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 862 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.11.18 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 20 και των λεωφορειακών γραμμών 300 και 904 στο Δήμο Πειραιά. λόγω της αθλητικής εκδήλωσης «Σκυταλοδρομία Πειραιάς Βίκος Street Relays Piraeus 2018» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.18 Λειτουργία ΜΜΜ λόγω των εκδηλώσεων εορτασμού της 45ης επετείου του Πολυτεχνείου από 06:00 της 15-11-2018 έως 06:00 της 18-11-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 501 (ΠΕΥΚΗ – ΜΑΡΟΥΣΙ) και  527 (ΠΕΥΚΗ – ΣΤ. ΝΕΡΑΤΖΙΩΤΙΣΣΑ)  λόγω της δράσης «Προϊόντα χωρίς μεσάζοντες», στο  Δήμο Λυκόβρυσης – Πεύκης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.18 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 732 λόγω έργων στην οδό Εθνάρχου Μακαρίου του Δήμου Βύρωνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.11.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 024 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.11.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 866, 878, 881 και Γ16 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.18 Προσωρινή Τροποποίηση των Λεωφ. Γραμμών 036 - 651 την 25-11-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.18 Λειτουργία ΜΜΜ λόγω της διεξαγωγής του 36ου Αυθεντικού Μαραθωνίου Αθηνών και των παράλληλων αγώνων δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.18 Προσωρινή τροποποίηση της λεωφορειακής γραμμής 732 λόγω έργων στο Δήμο Βύρωνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.11.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 725 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 704 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Μερική προσωρινή τροποποίηση της  διαδρομής της λεωφορειακής γραμμής 536, λόγω εργασιών στον Δήμο Διονύσου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.10.18 Προσωρινή Τροποποίηση και Μεταφορά Αφετηρίας της Λεωφορειακής Γραμμής 749 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.10.18 Αλλαγές στις μετακινήσεις προς και από  το Αεροδρόμιο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.10.18 Προσωρινές τροποποιήσεις της διαδρομής λεωφορειακών γραμμών, γραμμών τρόλεϊ και τραμ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.10.18 Προσωρινή αναστολή λειτουργίας της λεωφορειακής γραμμής Χ80 «ΠΕΙΡΑΙΑΣ- ΑΚΡΟΠΟΛΗ- ΣΥΝΤΑΓΜΑ EXPRESS» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.10.18 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΤΩΝ ΛΕΩΦ. ΓΡΑΜΜΩΝ 036, 046 - 653 ΤΗΝ 25-10-2018 - 26-10-2018 ΛΟΓΩ ΕΚΔΗΛΩΣΕΩΝ ΣΤΟΝ Ι.Ν. ΑΓ.ΔΗΜΗΤΡΙΟΥ ΣΤΗΝ ΟΔΟ ΠΑΝΟΡΜΟΥ ΤΟΥ ΔΗΜΟΥ ΑΘΗΝΑΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.10.18 Μερική προσωρινή τροποποίηση των διαδρομών των λεωφορειακών γραμμών  054, 605 και 444 λόγω εργασιών στον Δήμο Νέας Ιωνίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 054 την 21-10-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.18 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΤΩΝ ΛΕΩΦ. ΓΡΑΜΜΩΝ 036, 046 - 653 ΤΗΝ ΤΕΤΑΡΤΗ 25-10-17 - ΠΕΜΠΤΗ 26-10-17 ΛΟΓΩ ΕΚΔΗΛΩΣΕΩΝ ΣΤΟΝ Ι.Ν. ΑΓ.ΔΗΜΗΤΡΙΟΥ ΣΤΗΝ ΟΔΟ ΠΑΝΟΡΜΟΥ ΤΟΥ ΔΗΜΟΥ ΑΘΗΝΑΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 227 και της γραμμής τρόλεϊ 4 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.10.18 Λειτουργία των Μέσων Σταθερής Τροχιάς την Παρασκευή 19-10-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.10.18 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 447 λόγω έργων αντιπλημμυρικής προστασίας στην οδό Μεγ. Αλεξάνδρου στο Δήμο Βριλησσίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.18 Μερική προσωρινή τροποποίηση  της διαδρομής της  λεωφ. γραμμής 605  (ΠΕΡΙΣΣΟΣ – ΑΝΩ ΠΑΤΗΣΙΑ) από 17-10-2018 έως 23-10-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.18 Μερική τροποποίηση των λεωφορειακών  γραμμών  218, 904, 906, 909, 915,300 και 500 λόγω εργασιών ανακατασκευής της οδού Τσαμαδού στο Δήμο Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.10.18 Διακοπή δρομολογίων τραμ την Κυριακή </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 811 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.10.18 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 447 λόγω έργων αντιπλημμυρικής προστασίας στην οδό Μεγ. Αλεξάνδρου στο Δήμο Βριλησσίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 805 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.10.18 Πρόσκληση Εκδήλωσης Ενδιαφέροντος  για πώληση εισιτήριων των Αστικών Συγκοινωνιών Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.18 Λειτουργία ΜΜΜ την Κυριακή 7-10-2018 λόγω της διεξαγωγής του 10ου Αγώνα Δρόμου και Περιπάτου «Greece Race for the Cure» στο Δήμο Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.18 Λειτουργία  των ΜΜΜ την Τρίτη 2-10-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.09.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 504 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.18 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 447 κατά τις ημέρες  διεξαγωγής της λαϊκής αγοράς στην οδό Τυμφρηστού (περιοχή ΤΟΥΦΑ Χαλανδρίου) του Δήμου Χαλανδρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.18 Μερική προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 054, 444  και  605, λόγω εργασιών, στο Δήμο Ν. Ιωνίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.09.18 Επαναφορά της Προσωρινά Κατηργημένης Στάσης με την ονομασία “ΠΗΓΑΔΑΚΙ” </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.18 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 447 λόγω έργων αντιπλημμυρικής προστασίας στην οδό Μεγ. Αλεξάνδρου στο Δήμο Βριλησσίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 859 λόγω εκδηλώσεων  στον Ι.Ν. Αγ. Παντελεήμονος στη Δραπετσώνα του Δήμου Δραπετσώνας-Κερατσινίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.18 Μερική προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 504 και 726, λόγω εργασιών επί της οδού Μεγάλου Αλεξάνδρου του Δήμου Αχαρνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.18 Λειτουργία ΜΜΜ την Κυριακή 30-09-2018 λόγω της διεξαγωγής του 10ου Αγώνα Δρόμου και Περιπάτου «Greece Race for the Cure» στο Δήμο Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.09.18 Μερική προσωρινή τροποποίηση  της διαδρομής της  λεωφ. γραμμής 605  (ΠΕΡΙΣΣΟΣ – ΑΝΩ ΠΑΤΗΣΙΑ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.09.18 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 837 λόγω εργασιών στα πλαίσια του έργου «ΑΝΑΚΑΤΑΣΕΚΥΗ ΚΑΙ ΝΑΒΑΘΜΙΣΗ ΔΙΚΤΥΟΥ ΑΠΟΧΕΤΕΥΣΗΣ ΟΔΟΥ ΚΥΠΡΟΥ» στο Δήμο Αγίας Βαρβάρας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.09.18 Χειμερινά δρομολόγια για λεωφορεία και τρόλεϊ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.09.18 Λειτουργία ΜΜΜ την Τετάρτη 03-10-2018 λόγω του εορτασμού του Πολιούχου της Αθήνας Αγίου Διονυσίου του Αρεοπαγίτου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.09.18 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής  137 λόγω εκδήλωσης της Στέγης του Ιδρύματος Ωνάση την 4-10-2018. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.09.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.09.18 Μόνιμη μερική τροποποίηση της διαδρομής της λεωφορειακής γραμμής 876 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.09.18 Άνοδος εσόδων 12% τον Ιούλιο στον όμιλο ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.09.18 Μερική προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 731, 803 και Α15 του Δήμου Χαϊδαρίου, λόγω εργασιών.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.09.18 Μερική προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 705 και Γ12, λόγω εργασιών επί της οδού Έκτορος του Δήμου Ιλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.09.18 Λειτουργία των Λεωφορειακών Γραμμών 242, 250 και Ε90 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.08.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών Ευρύτερης Περιοχής Δήμων Αιγάλεω, Χαϊδαρίου, Ασπροπύργου και Ελευσίνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.08.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 711 και Β12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.08.18 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΛΕΩΦ. ΓΡΑΜΜΩΝ ΛΟΓΩ ΕΜΠΟΡΟΠΑΝΗΓΥΡΗΣ ΣΤΟΝ Ι.Ν. ΑΓ. ΜΕΛΕΤΙΟΥ ΣΤΗΝ ΟΔΟ ΒΟΡΕΙΟΥ ΗΠΕΙΡΟΥ ΣΤΟ ΔΗΜΟ ΑΘΗΝΑΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.08.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>23.07.18  Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 866 και Γ16 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.07.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής Γ10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.07.18 Θερινό πρόγραμμα δρομολογίων ΙΙ στις γραμμές Λεωφορείων και Τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.07.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.07.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 411 και 447 λόγω έργων αποκατάστασης οδοστρώματος, στο Δήμο Χαλανδρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.07.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 725 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.07.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.07.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 307 και 308 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.07.18 Λειτουργία των ΜΜΜ την Πέμπτη 12 Ιουλίου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.07.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 536, λόγω έργων στο Δήμο Διονύσου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.07.18 Λειτουργία των Λεωφορειακών Γραμμών 242, 250 και Ε90 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.07.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 537, 712, 721, 728, 733, 740, 752, 878, 879, A10 και B10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.07.18 Προσωρινή διακοπή λειτουργίας της λεωφορειακής γραμμής 416 λόγω έργων στο Δήμο Παπάγου-Χολαργού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.07.18 Λειτουργία ΜΜΜ τo Σάββατο 7-7-2018 λόγω της διεξαγωγής του «ANTETOKOUBROS 5K RUN» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.18 Λειτουργία ΜΜΜ την Τετάρτη 4-7-2018 λόγω διεξαγωγής Συναυλίας στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.18 Παράταση Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 700 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.07.18 Προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 022 και 060 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.06.18 Θερινά δρομολόγια μέσων σταθερής τροχιάς (ΣΤΑ.ΣΥ) 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.06.18 Λειτουργία των Μέσων Σταθερής Τροχιάς την Παρασκευή 29-6-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.06.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 164, 165 και Β1, λόγων έργων στην οδό Γ. Γεννηματά στη Γλυφάδα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.06.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών Δήμου Ιλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.06.18 Λειτουργία των ΜΜΜ την Δευτέρα 25-06-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.06.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 861 και 863 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.06.18 Λειτουργία των ΜΜΜ την Πέμπτη 21 Ιουνίου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.06.18 Λειτουργία ΜΜΜ το Σάββατο 23-6-2018 λόγω της διεξαγωγής του αγώνα δρόμου «SNF RUN-Τρέχοντας προς το μέλλον» την 23-6-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.06.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 740 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.06.18 Μόνιμη τροποποίηση της Λεωφορειακής Γραμμής 155 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.06.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 855 και 879 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.06.18 Μερική προσωρινή τροποποίηση λεωφ. γραμμών στο Δήμο Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.06.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής Γ10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.06.18 Λειτουργία των ΜΜΜ την Τρίτη 19 Ιουνίου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.06.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 725 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.06.18 Λειτουργία  των ΜΜΜ την Πέμπτη 14-06-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.06.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 725 και 726. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.06.18 Διακοπή δρομολογίων Τραμ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.06.18 Λειτουργία λεωφ. γραμμών 235, 608, 622 - 815 λόγω εργασιών στην οδό Παπαδιαμαντοπούλου στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.06.18 Λειτουργία λεωφ. γραμμής 230 σήμερα 1-6-2018 λόγω του Ράλλυ Ακρόπολις στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.05.18 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 406 και 421  λόγω διακοπής της κυκλοφορίας στην οδό Γιαβάση στο Δήμο Αγ. Παρασκευής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.05.18 Παράταση Προσωρινής Κατάργησης της Στάσης με την ονομασία “ΠΗΓΑΔΑΚΙ” </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.05.18 Λειτουργία  των ΜΜΜ την Πέμπτη 31-5-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.05.18 Λειτουργία  των ΜΜΜ την Τετάρτη 30-5-2018 και την Πέμπτη 31-5-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.05.18 Μερική Τροποποίηση της διαδρομής των γραμμών 15, 035 - 046 λόγω έργων στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.18 Παράταση Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 747 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.18 Προσωρινή μεταφορά των Τερμάτων των λεωφορειακών γραμμών 206, 237, 219, 816 εντός του Σταθμού Μετρό Δάφνης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.05.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 732 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.05.18 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 832 και της γραμμής τρόλεϊ 20 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.05.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 861 και 863 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.05.18 Λειτουργία των ΜΜΜ την Δευτέρα 14-5-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.05.18 Λειτουργία ΜΜΜ την Κυριακή 13-5-2018 λόγω της διεξαγωγής του 1ου Αγώνα Δρόμου για τον Ποντιακό - Μικρασιατικό Ελληνισμό στο Δήμο Αιγάλεω </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.05.18 Μερική προσωρινή τροποποίηση των λεωφ. Γραμμών 460,461,447 και 404 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.05.18 Μερική προσωρινή τροποποίηση των διαδρομών των λεωφορειακών γραμμών 832 και 833 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.05.18 Τροποποίηση διαδρομών  των λεωφορειακών γραμμών 218 και 860  και της γραμμής τρόλεϊ 1, λόγω πολιτιστικών εκδηλώσεων στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.05.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 224 λόγω  εκδηλώσεων στην Λεωφ. Εθν. Αντιστάσεως του Δήμου Καισαριανής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.05.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.04.18 Λειτουργία  των ΜΜΜ την Τρίτη 1 Μαΐου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.04.18 Ενοποίηση της Λεωφορειακής Γραμμής Α16 με τη Λεωφορειακή Γραμμή 876 και επέκταση της διαδρομής της μέχρι το Σταθμό Μετρό Αιγάλεω </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.04.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 700 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.18 Λειτουργία ΜΜΜ την Κυριακή 29-4-2018 λόγω της διεξαγωγής του 25ου Ποδηλατικού Γύρου της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών που διέρχονται την Γρ. Λαμπράκη μεταξύ Ελλησπόντου και Μαραθωνομάχων λόγω ποδηλατικού αγώνα στο Δήμο Νίκαιας-Α.Ι.Ρέντη </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 504, 725 και 726 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.18 Μερική Τροποποίηση της διαδρομής των γραμμών τρόλεϊ 2 - 4 στην Άνω Κυψέλη στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 537, 712, 721, 728, 733, 740, 752, 878, 879, Α10 και Β10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 824 λόγω εκδηλώσεων στην οδό Διονυσίου Αρεοπαγίτου  στο Δήμο Κερατσινίου-Δραπετσώνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.18 Λειτουργία ΜΜΜ την Τετάρτη 25 Απριλίου 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.04.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών 713, 723, 735, 878, 879 και Β12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>20.04.18 Παράταση Προσωρινής Τροποποίησης της Λεωφορειακής Γραμμής 747 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.04.18 Παράταση Προσωρινής Κατάργησης της Στάσης με την ονομασία “ΠΗΓΑΔΑΚΙ” </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>20.04.18 Μερική  προσωρινή τροποποίηση των λεωφορειακών  γραμμών A1, B1, B2, X96, 217, 550 και 860, την Κυριακή 22-4-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.04.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.04.18 Έκτακτη Μερική Τροποποίηση της διαδρομής των λεωφορειακών γραμμών  035, 046 - 060 στο Δήμο Αθηναίων λόγω επισκευής επείγουσας βλάβης ΕΥΔΑΠ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.04.18 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 405, 410, 530 στο Δήμο Πεντέλης λόγω θρησκευτικών εκδηλώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.04.18 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 406, και Β5 λόγω έργων κατασκευής δικτύου διανομής φυσικού αερίου στο Δήμο Αγ. Παρασκευής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.04.18 Προσωρινή Μεταφορά της Αφετηρίας της λεωφορειακής γραμμής Χ95 - Μερική Τροποποίηση της διαδρομής των γραμμών  Χ95 - 856 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.04.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών Δήμου Ιλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>12.04.18  Προσωρινή τροποποίηση των λεωφορειακών γραμμών 537, 721,  740 και 755   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.04.18 Μερική τροποποίηση λεωφορειακών γραμμών και Ίδρυση προσωρινών στάσεων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>04.04.18 Λειτουργία ΜΜΜ την Κυριακή 15-4-2018 λόγω της διεξαγωγής του 2ου Αγώνα Δρόμου Πεδίου Άρεως «Στις γειτονιές της Αθήνας» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.04.18 Προσωρινή  τροποποίηση των λεωφορειακών γραμμών  230,235 και 608, λόγω συνάντησης επιταφίων στο Δήμο Ζωγράφου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.04.18 Δρομολόγια ΣΤΑΣΥ κατά τη διάρκεια των εορτών του Πάσχα 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.04.18 Δρομολόγια Λεωφορείων και τρόλεϊ (Ο.ΣΥ.) κατά τη διάρκεια των εορτών του Πάσχα 2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.03.18 Προσωρινή Μεταφορά της Αφετηρίας της λεωφορειακής γραμμής Χ95 - Μερική Τροποποίηση της διαδρομής των γραμμών  Χ95 - 856 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.03.18 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών 040, 910,  218, 219 και των γραμμών τρόλεϊ 1,5,10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.03.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.03.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών 713, 723, 733, 749 και Β12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.03.18 Τροποποιήσεις στα δρομολόγια του Τραμ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.03.18 Διακοπή δρομολογίων ΤΡΑΜ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.03.18 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.03.18 Μερική προσωρινή τροποποίηση της στη διαδρομή των λεωφορειακών γραμμών 124, 164, 165 και Β1, λόγων έργων στη λεωφόρο Κ. Αθανάτου στην Άνω Γλυφάδα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.03.18 Προσωρινές τροποποιήσεις λόγω των εκδηλώσεων εορτασμού της Εθνικής Επετείου της 25ης Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.03.18 Λειτουργία ΜΜΜ την Κυριακή 18-3-2018 λόγω της διεξαγωγής του 7ου Ημιμαραθωνίου Δρόμου Αθηνών και των παράλληλων αγώνων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.03.18 Μερική προσωρινή τροποποίηση  της διαδρομής των  λεωφ. γραμμών 524 και 526 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.03.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 801, 836 και 871 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.03.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 748 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.03.18 Καθυστέρηση Δρομολογίων Λεωφορειακών Γραμμών 421, 703 και Γ10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.03.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.03.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 701 και 705 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.03.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής Γ12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>28.02.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 747 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.02.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.02.18 Ίδρυση  προσωρινής κυκλικής λεωφορειακής γραμμής Χ6 (ΣΤ. ΣΥΓΓΡΟΥ ΦΙΞ- ΝΕΑ ΣΜΥΡΝΗ), λόγω της διακοπής των  δρομολογίων Τραμ στο τμήμα «Μουσών- Σύνταγμα», από 24-2-2018 έως 6-3-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.02.18 Προσωρινή Κατάργηση της Στάσης με την ονομασία “ΠΗΓΑΔΑΚΙ” </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.02.18 Λειτουργία  των ΜΜΜ την Τρίτη 20-2-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.02.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 731, 803 και Α15 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.02.18 Προσωρινές τροποποιήσεις στη διαδρομή της λεωφορειακής γραμμής 330, λόγων έργων στην οδό Ταξιαρχών στην Αγ. Μαρίνα, στο Δήμο Κρωπίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.02.18 Τροποποίηση διαδρομών λεωφορειακών γραμμών και γραμμής τρόλεϊ λόγω αποκριάτικων εκδηλώσεων στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.02.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 817 και 863 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.02.18 Παράταση Μερικής Τροποποίησης της διαδρομής των λεωφορειακών γραμμών  035 - 227 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.02.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.02.18 Λειτουργία ΜΜΜ  την Κυριακή 04-02-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.02.18 Τροποποιήσεις στις διαδρομές των λεωφορειακών γραμμών 101, 217 και Α2, λόγων εργασιών επί της λεωφόρου Ελευθερίας,  στον Άλιμο από 3.2.2018 έως και 6.2.2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.01.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 024 και Γ10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.01.18 Προσωρινή Τροποποίηση της Λεωφορειακής Γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.01.18 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 530 λόγω έργων κατασκευής δικτύου διανομής φυσικού αερίου στο Δήμο Πεντέλης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.01.18 Παράταση Μερικής Τροποποίησης της διαδρομής των λεωφορειακών γραμμών  035 - 227 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.01.18 Λειτουργία  των ΜΜΜ τη Δευτέρα 15-1-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.01.18 Λειτουργία  των ΜΜΜ την Παρασκευή  12-1-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.01.18 Έκτακτη Μερική Τροποποίηση της διαδρομής των λεωφορειακών γραμμών  035 - 227 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.01.18 Μερική Τροποποίηση της διαδρομής της λεωφορειακής γραμμής 051 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.01.18 Μερική προσωρινή τροποποίηση της διαδρομής της λεωφορειακής γραμμής 891 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.01.18 Προσωρινή Τροποποίηση των Λεωφορειακών Γραμμών 024 και Γ10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>28.12.17 Τελευταία δρομολόγια λεωφορείων - τρόλεϊ στις 31-12-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.12.17 ΛΕΙΤΟΥΡΓΙΑ ΜΜΜ ΧΡΙΣΤΟΥΓΕΝΝΑ ΠΡΩΤΟΧΡΟΝΙΑ 2017-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.12.17 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών 218,860 και γραμμής τρόλεϊ 1,  λόγω εκδήλωσης στην οδό Στ. Μακρυγιάννη στο Δήμο Μοσχάτου-Ταύρου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.12.17 Επαναφορά των λεωφορειακών  γραμμών 830 και 892 στην τυπική τους διαδρομή  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.12.17 Επαναφορά των λεωφορειακών γραμμών 817 και 863 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.17 Λειτουργία  των ΜΜΜ την Πέμπτη 14-12-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>13.12.17 Μερική προσωρινή τροποποίηση των λεωφορειακών  γραμμών 021 και 046 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.12.17 Λειτουργία  των ΜΜΜ την Πέμπτη 14-12-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.12.17 Προσωρινή Τροποποίηση των λεωφορειακών γραμμών 731, 803 και Α15 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.12.17 Λειτουργία λεωφορειακής γραμμής 230 την Κυριακή 10-12-2017 λόγω της διεξαγωγής του αγώνα δρόμου «THE TOC MERRYTHON» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.12.17 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.12.17 Προσωρινή Τροποποίηση της λεωφορειακής γραμμής 730 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.12.17 Κλειστός ο σταθμός Σύνταγμα την Πέμπτη 7-12-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.17 Προσωρινή Τροποποίηση των λεωφορειακών γραμμών 817 και 863. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.17 Διακοπή κυκλοφορίας της Γραμμής Τραμ στο τμήμα Λεωφόρος Βουλιαγμένης – Σύνταγμα από την Κυριακή 10-12-2017 έως το Σάββατο 10-3-2018 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.17 Κλειστοί Σταθμοί Μέσων Σταθερής Τροχιάς την Τετάρτη  6-12-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.12.17 Λειτουργία ΜΜΜ την Πέμπτη 07-12-2017 - Παρασκευή 08-12-2017 λόγω της επίσκεψης του Προέδρου της Δημοκρατίας της Τουρκίας κ. RECEP TAYYIP ERDOGAN </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.12.17 Λειτουργία των ΜΜΜ κατά την διάρκεια των κυκλοφοριακών ρυθμίσεων της ΕΛ.ΑΣ. λόγω των εκδηλώσεων-κινητοποιήσεων  για τη συμπλήρωση εννέα ετών από τον θανάσιμο τραυματισμό του Αλέξανδρου Γρηγορόπουλου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.12.17 Τροποποίηση στη διαδρομή της λεωφορειακής γραμμής 141, λόγω εργασιών επί της οδού Γρ. Αυξεντίου στον Άλιμο από 5.12.2017 έως και 12.12.2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.12.17 Επανίδρυση της λεωφορειακής γραμμής 861, καθώς και προσωρινή τροποποίηση της διαδρομής της. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.11.17 Τροποποίηση της διαδρομής της λεωφορειακής γραμμής 891 ΑΙΓΑΛΕΩ-ΠΕΡΙΣΤΕΡΙ-ΣΤ.ΑΤΤΙΚΗΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.11.17 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 407 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.11.17 Αλλαγές στην λειτουργία της λεωφορειακής γραμμής 204 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>28.11.17 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.11.17 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 809, 810 λόγω εορταστικής πανήγυρης του Ι.Ν. Αγ. Στυλιανού του Δήμου Κορυδαλλού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.11.17 Διαλειτουργικότητα δικτύων ΟΑΣΑ και ΤΡΑΙΝΟΣΕ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.11.17 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 550 και 860 για τo Σάββατο 25-11-2017  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.11.17 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 859 λόγω εργασιών στην οδό Καζαντζάκη του Δήμου Κερατσινίου-Δραπετσώνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Τρίτη 21-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Τετάρτη 15-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.17 Λειτουργία ΜΜΜ λόγω των εκδηλώσεων εορτασμού της 44ης επετείου του Πολυτεχνείου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Δευτέρα 13-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.11.17 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 550 και 860 λόγω έργων στην Μαρίνα Φλοίσβου στο  Δήμο Παλαιού Φαλήρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.11.17 Προσωρινή  αναστολή λειτουργίας της λεωφορειακής γραμμής Χ80 «ΠΕΙΡΑΙΑΣ- ΑΚΡΟΠΟΛΗ- ΣΥΝΤΑΓΜΑ EXPRESS» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Παρασκευή 10-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.11.17 Λειτουργία ΜΜΜ το Σάββατο 11-11-2017 και την Κυριακή 12-11-2017 λόγω της διεξαγωγής του 35ου Αυθεντικού Μαραθωνίου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.11.17 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Τρίτη 07-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.11.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Πέμπτη 02-11-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.10.17 Λειτουργία ΜΜΜ την Δευτέρα 30-10-2017 - Τρίτη 031-10-2017 λόγω των εκδηλώσεων κατά την παράδοση - παραλαβή της Ολυμπιακής Φλόγας για τους Χειμερινούς Ολυμπιακούς Αγώνες «PYEONGCHANG 2018» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>26.10.17 Διακοπή κυκλοφορίας της γραμμής τραμ την Κυριακή 29-10-2017 λόγω εργασιών ΔΕΔΔΗΕ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.17 ΛΕΙΤΟΥΡΓΙΑ ΤΩΝ ΜΜΜ ΤΗΝ ΠΕΜΠΤΗ 26-10-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.17 ΤΡΟΠΟΠΟΙΗΣΗ ΤΗΣ ΔΙΑΔΡΟΜΗΣ ΤΩΝ ΛΕΩΦ. ΓΡΑΜΜΩΝ 036, 046 - 653 ΤΗΝ ΤΕΤΑΡΤΗ 25-10-17 - ΠΕΜΠΤΗ 26-10-17 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.10.17 Προσωρινές τροποποιήσεις της διαδρομής γραμμών λεωφορείων, τρόλεϊ και τραμ λόγω του εορτασμού της Εθνικής Επετείου της 28ης Οκτωβρίου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.10.17 Διακοπή κυκλοφορίας της γραμμής τραμ την Κυριακή 29-10-2017 λόγω εργασιών ΔΕΔΔΗΕ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.10.17 Mερική προσωρινή τροποποίηση των λεωφ. γραμμών 040, 910 για το Σάββατο 21-10-2017  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.10.17 Λειτουργία ΜΜΜ την Κυριακή 22-10-2017 λόγω της διεξαγωγής του 31ου Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.17 Διαδικασία έκδοσης προσωποποιημένων καρτών με κατάθεση φακέλου από τους επιβάτες και αποστολής της ηλεκτρονικής κάρτας στην διεύθυνση επιλογής τους. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.10.17 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών  824 και 825 στο Δήμο Κερατσινίου-Δραπετσώνας από Σάββατο 14-10-2017  έως Κυριακή 15-10-2017, λόγω εργασιών ανακατασκευής του οδοστρώματος </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.10.17 Μερική προσωρινή τροποποίηση της λεωφορειακής  γραμμής 824 στο Δήμο Κερατσινίου-Δραπετσώνας από την Παρασκευή 13-10-2017 έως  το Σάββατο 14-10-2017, λόγω εργασιών ανακατασκευής του οδοστρώματος </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.10.17 Λειτουργία ΜΜΜ την Κυριακή 15-10-2017 λόγω της διεξαγωγής του Λαϊκού Αγώνα Δρόμου: «Αθήνα Ελεύθερη 1944-2017» την Κυριακή 15-10-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.10.17 Mερική προσωρινή τροποποίηση των λεωφ. γραμμών 421, 619, Β9, 755 και των  τρόλεϊ 3 και 6,  λόγω των εκδηλώσεων για τον «1ο Αγώνα Δρόμου Γεώργιος Παπαβασιλείου», στο Δήμο Ν. Φιλαδέλφειας - Χαλκηδόνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.10.17 Πληροφορίες για  Δικαιούχους δωρεάν μετακίνησης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.10.17 Λειτουργία MMM τη Δευτέρα  9-10-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.10.17 Λειτουργία ΜΜΜ την Κυριακή 22-10-2017 λόγω της διεξαγωγής του 31ου Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.09.17 Τροποποίηση στη διαδρομή των λεωφορειακών γραμμών 140 και 201, λόγων εργασιών στην πλατεία Παλαιών Πατρών Γερμανού στην Ηλιούπολη </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.09.17 Λειτουργία ΜΜΜ την Κυριακή 1-10-2017 λόγω της διεξαγωγής του 9ου Αγώνα Δρόμου και Περιπάτου Greece Race for the Cure στο Δήμο Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.17 Ανακοίνωση Αθλητικών Αγώνων Δήμου Βύρωνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.09.17 Ίδρυση προσωρινής κυκλικής λεωφορειακής γραμμής Χ7 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.09.17 Λειτουργία MMM την Πέμπτη 21-9-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.09.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Πέμπτη 14-9-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.09.17 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 832 λόγω  εργασιών στη οδό Σωκράτους,  του Δήμου Κερατσινίου-Δραπετσώνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.09.17 Μερική προσωρινή τροποποίηση της γραμμής τρόλεϊ 21 λόγω εκδηλώσεων στον Ι.Ν. Αγ. Νικολάου Νίκαιας στο Δήμο Νίκαιας- Α.Ι.Ρέντη </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.09.17 Λειτουργία ΜΜΜ την Πέμπτη 07-09-2017 - Παρασκευή 08-09-2017 λόγω της επίσκεψης του Προέδρου της Γαλλίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.08.17 Ανακοίνωση για Δευτέρα 14-8-201 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>04.08.17 Mερική προσωρινή τροποποίηση της λεωφ. γραμμής 402 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.07.17 Mερική προσωρινή τροποποίηση της λεωφ. γραμμής 230 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.07.17 Λειτουργιά Των Λεωφορειακών Γραμμών 242, 250 και Ε90 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.07.17 Τροποποιήσεις στις διαδρομές των λεωφορειακών γραμμών 101 και 109 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.07.17 Μερική τροποποίηση λεωφ. γραμμών λόγω έργων τραμ στην ακτή Ποσειδώνος στο δήμο Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.07.17 Προσωρινή τροποποίηση της διαδρομής των λεωφορειακών γραμμών 022 και         060   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.06.17 Το 95,8% των επιβατών δηλώνει ότι βελτιώθηκε η ποιότητα των μετακινήσεων με τη τηλεματική </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.06.17 Θερινά δρομολόγια για λεωφορεία και τρόλεϊ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.06.17 Λειτουργία ΜΜΜ την Παρασκευή 23-06-2017 λόγω της διεξαγωγής του αγώνα δρόμου «SNF Run-Τρέχοντας προς το μέλλον»  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.06.17 ΛΕΙΤΟΥΡΓΙΑ ΛΕΩΦΟΡΕΙΩΝ ΚΑΙ ΤΡΟΛΕΪ ΤΗΝ ΤΡΙΤΗ 13 ΙΟΥΝΙΟΥ 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.06.17 Πρόγραμμα δρομολογίων την ημέρα του Αγίου Πνεύματος Δευτέρα         05-6-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>26.05.17 Προσωρινή τροποποίηση της λεωφ. γραμμής 418 από την Δευτέρα 29-5-2017 έως και την Κυριακή 18-6-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.17 Λειτουργία ΜΜΜ την Κυριακή 28-05-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.05.17  Τροποποιήσεις των λεωφορειακών γραμμών 120, 309 και 330 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.05.17 Καθυστερήσεις δρομολογίων λεωφορείων-τρολλεϋ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.05.17 ΛΕΙΤΟΥΡΓΙΑ ΔΡΟΜΟΛΟΓΙΩΝ ΤΡΟΛΕΪ ΤΗΝ ΤΕΤΑΡΤΗ 17 ΜΑΪΟΥ 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.05.17 Τροποποίηση της από τέρμα διαδρομής της λεωφορειακής γραμμής Α5 στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.05.17 ΛΕΙΤΟΥΡΓΙΑ ΔΡΟΜΟΛΟΓΙΩΝ ΛΕΩΦΟΡΕΙΩΝ ΤΟ ΤΡΙΗΜΕΡΟ 16, 17 και 18 ΜΑΪΟΥ 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.05.17 Μερική προσωρινή τροποποίηση, για την Κυριακή 14-05-2017των γραμμών 421, 619, Β9, 755 και των τρόλεϊ 3 και 6  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.05.17 Μερική προσωρινή τροποποίηση, 12-5-17 έως  13-5-17, της διαδρομής των λεωφ. γραμμών 036 και 622. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.05.17  Τροποποιήσεις στις διαδρομές των λεωφορειακών γραμμών 112, 141, 217, 219, 229 και 816 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.05.17 Τροποποιήσεις στις διαδρομές των λεωφορειακών γραμμών στον  ΑΓ. ΔΗΜΗΤΡΙΟ και στη  ΓΛΥΦΑΔΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.05.17 Προσωρινή τροποποίηση της λεωφ. γραμμής 224 για την Κυριακή 7-5-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.05.17 Τροποποίηση διαδρομών λεωφορειακών γραμμών και γραμμής τρόλεϊ στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.05.17 Λειτουργία ΜΜΜ την Κυριακή 7-5-2017 λόγω της διεξαγωγής του Ποδηλατικού Γύρου της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.17 Απαντήσεις επί διευκρινιστικών ερωτήσεων για το συνοπτικό διαγωνισμό με θέμα την ανάθεση υπηρεσιών καθαρισμού των γραφείων του ΟΑΣΑ για ένα έτος. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.17 Αναρτήθηκε το ΤΕΥΔ σε επεξεργάσιμη μορφή για την ανάθεση υπηρεσιών «ΚΑΘΑΡΙΣΜΟΥ ΤΩΝ ΓΡΑΦΕΙΩΝ ΤΟΥ Ο.Α.Σ.Α. ΓΙΑ ΧΡΟΝΙΚΟ ΔΙΑΣΤΗΜΑ ΕΝΟΣ ΕΤΟΥΣ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.04.17 Αναρτήθηκε το ΤΕΥΔ σε επεξεργάσιμη μορφή για την ανάθεση υπηρεσιών «ΦΥΛΑΞΗΣ ΤΩΝ ΓΡΑΦΕΙΩΝ ΤΟΥ Ο.Α.Σ.Α. ΓΙΑ ΧΡΟΝΙΚΟ ΔΙΑΣΤΗΜΑ ΕΝΟΣ ΕΤΟΥΣ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.04.17 Τροποποίηση της διαδρομής των λεωφορειακών γραμμών 101, 124, 154 και 205 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.04.17 Mερική προσωρινή τροποποίηση των λεωφ. γραμμών 550 και 860 για την Κυριακή 23-4-2017  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.04.17 Αποζημίωση 24ης απεργίας στα μ.μ.μ για τον μήνα Φεβρουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.04.17 Δρομολόγια Λεωφορείων και τρόλλεϋ (Ο.ΣΥ.) κατά τη διάρκεια των εορτών του Πάσχα 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.04.17 Πρώτα και τελευταία δρομολόγια της ΣΤΑ.ΣΥ. για την περίοδο Πάσχα 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>31.03.17 Προσωρινή τροποποίηση των λεωφ. γραμμών 040,910, 218, 219 και των γραμμών τρόλεϊ 1,5,10 για την Κυριακή 2-4-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.03.17 Προσωρινή τροποποίηση της γραμμής τρόλεϊ 10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.03.17 Aποζημιώσεις για τις μηνιαίες κάρτες ΦΕΒΡΟΥΑΡΙΟΥ - ΜΑΡΤΙΟΥ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.03.17 Προσωρινές τροποποιήσεις λόγω των εκδηλώσεων εορτασμού της Εθνικής Επετείου της 25ης Μαρτίου 2017, για τις ημέρες Παρασκευή και Σάββατο 24 - 25 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.03.17 ΚΛΕΙΣΤΟΙ ΟΙ ΣΤΑΘΜΟΙ ΤΟΥ ΜΕΤΡΟ «ΑΓ. ΙΩΑΝΝΗΣ» (Γραμμή 2) και «ΚΕΡΑΜΕΙΚΟΣ» (Γραμμή 3) ΣΤΙΣ 22-3-2017 ΛΟΓΩ ΕΡΓΑΣΙΩΝ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.03.17 Λειτουργία ΜΜΜ την Κυριακή 19-3-2017 λόγω της διεξαγωγής του 6ου Ημιμαραθωνίου Δρόμου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.03.17 ΚΛΕΙΣΤΟΙ ΟΙ ΣΤΑΘΜΟΙ ΤΟΥ ΜΕΤΡΟ «ΑΝΘΟΥΠΟΛΗ»  ΚΑΙ «ΑΙΓΑΛΕΩ»ΣΤΙΣ  11,12,13-3-2017  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.03.17 ΚΛΕΙΣΤΟΙ ΟΙ ΣΤΑΘΜΟΙ ΤΟΥ ΜΕΤΡΟ «ΠΕΡΙΣΤΕΡΙ» και «ΚΕΡΑΜΕΙΚΟΣ» ΣΤΙΣ 7,8,9-3-2017 ΛΟΓΩ ΕΡΓΑΣΙΩΝ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.03.17 ΚΛΕΙΣΤΟΙ ΟΙ ΣΤΑΘΜΟΙ ΤΟΥ ΜΕΤΡΟ «ΕΛΛΗΝΙΚΟ», «ΑΛΙΜΟΣ»,  «ΑΓ. ΑΝΤΩΝΙΟΣ» (Γραμμή 2) και «ΑΜΠΕΛΟΚΗΠΟΙ», «ΧΑΛΑΝΔΡΙ»  (Γραμμή 3) ΤΟ ΣΑΒΒΑΤΟΚΥΡΙΑΚΟ 4 και 5-3-2017 ΛΟΓΩ ΕΡΓΑΣΙΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.03.17 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 409 και 413 για την Πέμπτη 2-3-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.17 Οι προγραμματισμένες εργασίες στο σταθμό «ΠΕΡΙΣΤΕΡΙ» αναβάλλονται </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.17 Λειτουργία Γραμμών 1, 2 και 3 του μετρό και του τραμ την Τετάρτη 1 Μαρτίου και την Παρασκευή 3 Μαρτίου 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.02.17 ΚΛΕΙΣΤΟΣ Ο ΣΤΑΘΜΟΣ ΤΟΥ ΜΕΤΡΟ «ΠΕΡΙΣΤΕΡΙ» (Γραμμή 2) ΣΤΙΣ 1,2,3-3-2017  ΛΟΓΩ ΕΡΓΑΣΙΩΝ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.02.17 Mερική προσωρινή τροποποίηση της λεωφ. γραμμής 224 για την Κυριακή 26-2-2017  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.02.17 Λειτουργiα σταθμού Μετρό «ΣΥΝΤΑΓΜΑ» (Γραμμή 2 - 3) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.02.17 Τροποποίηση διαδρομών λεωφορειακών γραμμών και γραμμής τρόλεϊ λόγω αποκριάτικων εκδηλώσεων στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.02.17 Λειτουργία Μέσων Σταθερής Τροχιάς την Παρασκευή 17 Φεβρουαρίου 2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.02.17 Λειτουργiα σταθμού του Μετρό «ΟΜΟΝΟΙΑ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>03.02.17 Λειτουργία ΜΜΜ την Κυριακή 05-02-2017 λόγω της διεξαγωγής του αγώνα δρόμου «ΛΕΩΦΟΡΟΣ ΔΡΟΜΕΩΝ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.02.17 Επαναφορά σε κανονική λειτουργία των λεωφ. γραμμών 409 - 413 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.01.17 Τροποποίηση λεωφ. γραμμής 724 και ίδρυση γραμμών 725 - 726 από Τετάρτη 1 Φεβρουαρίου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.01.17 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 409 και 413 λόγω καθίζησης του οδοστρώματος  στην οδό Πίνδου στο Δήμο Παπάγου Χολαργού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.01.17 Στάση εργασίας εργαζομένων σε ΜΕΤΡΟ (γραμμές 2 - 3) την Παρασκευή 12:00 - 16:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.01.17 Τροποποιήσεις λεωφ. γραμμών λόγω αγώνα μπάσκετ στο ΟΑΚΑ τη Δευτέρα 30-01-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.01.17 Τροποποιήσεις λεωφορειακών γραμμών λόγω αγώνα μπάσκετ στο στάδιο ΟΑΚΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.01.17 Περιορισμένα προβλημάτα στο δίκτυο λόγω παγετού ή χιονόπτωσης - Σημερινή κατάσταση δικτύου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.01.17 Προβλήματα λειτουργίας λεωφ. γραμμών λόγω χιονόπτωσης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.01.17 ΕΚΤΑΚΤΗ ΑΝΑΚΟΙΝΩΣΗ: Προβλήματα στις λεωφ. γραμμές λόγω χιονόπτωσης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.01.17 Συνεχίζονται τα προβλήματα σε κάποιες λεωφ. γραμμές λόγω παγετού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.01.17 Περιορισμένα προβλημάτα στο δίκτυο λόγω παγετού ή χιονόπτωσης - Σημερινή κατάσταση δικτύου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.01.17 Περιορισμένα προβλημάτα στο δίκτυο λόγω παγετού ή χιονόπτωσης - Σημερινή κατάσταση δικτύου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.12.16 Περιορισμός προβλημάτων λόγω παγετού - Σημερινή κατάσταση δικτύου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.12.16 Περιορισμός προβλημάτων λόγω παγετού  - Σημερινή κατάσταση δικτύου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>29.12.16 Προβλήματα ΜΜΜ λόγω χιονοπτώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.12.16 ΣΤΑ.ΣΥ.  -   ΣΥΧΝΟΤΗΤΕΣ ΔΙΕΛΕΥΣΗΣ ΣΥΡΜΩΝ ΕΟΡΤΑΣΤΙΚΩΝ  ΔΡΟΜΟΛΟΓΙΩΝ 2016-2017 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.12.16 Πρόγραμμα λεωφορείων και τρόλεϊ την εορταστική περίοδο Χριστουγέννων - Πρωτοχρονιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.12.16 ΧΑΙΡΕΤΙΣΜΟΣ ΠΡΟΕΔΡΟΥ ΤΟΥ ΟΑΣΑ ΤΑΣΟΥ ΤΑΣΤΑΝΗ ΣΤΗΝ ΕΚΔΗΛΩΣΗ ΕΟΡΤΑΣΜΟΥ 40 ΧΡΟΝΩΝ ΤΟΥ ΣΥΛΛΟΓΟΥ ΕΛΛΗΝΩΝ ΣΥΓΚΟΙΝΩΝΙΟΛΟΓΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.12.16 Τροποποίηση της διαδρομής των λεωφορειακών γραμμών 141 και 142 στην οδό Γρ. Αυξεντίου στο Δήμο Αλίμου από 15-12-2016 έως 21-12-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.12.16 Τροποποίηση της διαδρομής των λεωφορειακών γραμμών 117 και 122, λόγω διεξαγωγής αγώνα δρόμου (RUN THE LAKE) στη Βουλιαγμένη, την Κυριακή 18-12-2016 από 09:00 έως και 12:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>09.12.16 Τροποποίηση της διαδρομής της λεωφορειακής γραμμής 109 λόγων στην οδό Καρναβία στο Δήμο Αλίμου από 12-12-2016 έως 17-12-2016: </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.12.16 Λειτουργία λεωφορειακής γραμμής 230 την Κυριακή 11-12-2016 λόγω της διεξαγωγής του αγώνα δρόμου «THE TOC MERRYTHON» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.12.16 Τροποποίηση της διαδρομής της λεωφορειακής γραμμής 237  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.16 Κλειστοί σταθμοί μετρό την Τρίτη 6-12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.12.16 Λειτουργία ΜΜΜ την Πέμπτη 8-12 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.12.16 Συγκοινωνιακές ρυθμίσεις την Κυριακή 4-12 στον Δήμο Φιλοθέης - Ψυχικού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>02.12.16 Λειτουργία ΜΜΜ την Κυριακή 04-12-2016 λόγω της διεξαγωγής του 3ου αγώνα δρόμου «ATHENS SANTA RUN» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.12.16 Λειτουργία ΜΜΜ την Παρασκευή 2 Δεκεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.11.16 Λειτουργία ΜΜΜ την Τετάρτη 30-11 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.11.16 Λειτουργία ΜΜΜ τη Δευτέρα 28 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.11.16 Τροποποιήσεις λεωφ. γραμμών στη γέφυρα ΗΣΑΠ στην κατευθυνση προς Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.11.16 Λειτουργία ΜΜΜ την Πέμπτη 24.11 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.11.16 Λειτουργία ΜΜΜ στις 21 - 22 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.11.16 ΜΕΡΙΚΗ ΤΡΟΠΟΠΟΙΗΣΗ ΛΕΩΦ. ΓΡΑΜΜΗΣ 915 ΣΤΟ ΛΟΦΟ ΒΩΚΟΥ ΔΗΜΟΥ ΠΕΙΡΑΙΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.11.16 Μεταφορά αφετηριών λεωφ. γραμμών 444 410 Α8 λόγω αγώνα για το Ευρωπαϊκό πρωτάθλημα μεταξύ των ομάδων  «ΠΑΝΑΘΗΝΑΙΚΟΣ SUPERFOODS – Ο.Σ.Φ.Π»,  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.11.16 Μερική τροποποίηση διαδρομής γραμμών 608 235 230 για τν Κυριακή 20-11-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.11.16 Διαγωνισμός φωτογραφίας - βίντεο με τίτλο -"ΜΕΣΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.11.16 Λειτουργία ΜΜΜ την Πέμπτη - Παρασκευή 17-18 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.11.16 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ την 16-11-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.16 Λειτουργία Μέσων σταθερής τροχιάς την Τρίτη 15 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.11.16 Κυκλοφοριακές ρυθμίσεις και μέτρα λόγω της επίσκεψης του Αμερικανού Προέδρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>14.11.16 Λειτουργία ΜΜΜ από 06:00 της 15-11-2016 έως 06:00 της 18-11-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.11.16 Επαναφορά τυπικών διαδρομών λεωφορειακών γραμμών στην οδό Χρυσοστόμου Σμύρνης του Δήμου Μοσχάτου - Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.11.16 Λειτουργία ΜΜΜ το Σάββατο 12-11-2016 και την Κυριακή 13-11-2016 λόγω της διεξαγωγής του  34ου Αυθεντικού Μαραθωνίου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.11.16 Στάση εργασίας σε Ηλεκτρικό Σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.11.16 Τροποποιήσεις των Λεωφορειακών Γραμμών 845 και Α16 το Σαββατοκύριακο λόγω εορταστικών εκδηλώσεων της Πολεμικής Αεροπορίας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Τροποποιήσεις λεωφ. γραμμών 541, Β9 λόγω 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Τροποποιήσεις λεωφ. γραμμών 421, 619, Β9, Γ9 - τρόλλεϋ 3, 6 λόγω 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Τροποποιήσεις λεωφ. γραμμών Α8 και 642 λόγω 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Τροποποιήσεις γραμμών 036, 140, 402 λόγω 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Τροποποιήσεις λεωφ. γραμμών 541 - 501 στο Μαρούσι λόγω της παρέλασης της 28ης Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.10.16 Λειτουργία ΜΜΜ την Παρασκευή 28 Οκτωβρίου λόγω μαθητικών παρελάσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.10.16 Λειτουργία ΜΜΜ την Κυριακή 23-10-2016 λόγω της διεξαγωγής του 30ου Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>21.10.16 Μερική προσωρινή τροποποίηση διαδρομών λεωφ. γραμμών λόγω διοργάνωσης λαϊκού αγώνα δρόμου στον Δήμο Ζωγράφου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.10.16 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών λόγω της διοργάνωσης του 1ου νυχτερινού αγώνα δρόμου σε Δημόσιο χώρο «Kallitheanightrun 2016» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.10.16 Κυριακή 16-10: Προσωρινή ολιγόωρη διακοπή λειτουργίας γραμμής 653 στο Ψυχικό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.10.16 Λειτουργία ΜΜΜ την Τετάρτη 12 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.10.16 Λειτουργία ΜΜΜ την Τρίτη 4 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.10.16 Λειτουργία ΜΜΜ την Δευτέρα 03-10-2016 λόγω του εορτασμού του Πολιούχου της Αθήνας Αγίου Διονυσίου του Αρεοπαγίτου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.09.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών και καθυστερήσεις στην εκτέλεση των προγραμματισμένων δρομολογίων λόγω της διοργάνωσης «Αγώνες Ιστορικής Μνήμης-Νέα Σμύρνη 2016» του Δήμου Νέας Σμύρνης. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.09.16 Ο ΟΑΣΑ και η ΟΣΥ χορηγοί στη «Βραδιά του Ερευνητή» στο Εθνικό Μετσόβιο Πολυτεχνείο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.09.16 Acropolis Night Run - Προσωρινή τροποποίηση διαδρομής γραμμής 230 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.09.16 Τροποποιήσεις λεωφ. γραμμών στο Δήμο Μοσχάτου - Ταύρου λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.09.16 Λειτουργία ΜΜΜ την Κυριακή 25-09-2016 λόγω της διεξαγωγής του 8ου Αγώνα Δρόμου και Περιπάτου Greece Race for the Cure στο Δήμο Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.09.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών 136 - 137 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.09.16 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών 847, 852,825,824,800,848 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.09.16 Ο ΟΑΣΑ ΣΥΜΜΕΤΕΧΕΙ ΚΑΙ ΣΤΗΡΙΖΕΙ ΤΗΝ ΕΥΡΩΠΑΪΚΗ ΕΒΔΟΜΑΔΑ ΚΙΝΗΤΙΚΟΤΗΤΑΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.09.16 Προσωρινή τροποποίηση της λεωφ. γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.09.16 Προσωρινή τροποποίηση των λεωφ. γραμμών 035 και 816, λόγω εορτασμού του Ι.Ν. Αγ. Σοφίας στη Δημοτική Κοινότητα Ταύρου στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.09.16 Στάση εργασίας σε λεωφορεία και τρόλλεϋ την Πέμπτη 15-09 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.09.16 Τροποποίηση των λεωφορειακών γραμμών 036, 140 και 402, λόγω των εκδηλώσεων για τον εορτασμό του Ι.Ν. Αγίας Σοφίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.09.16 Χειμερινά δρομολόγια σε λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.09.16 Εφαρμογή προγράμματος -"θερινό 1-" σε λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.08.16 Tροποποίηση της  λεωφορειακής γραμμής 829 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.07.16 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 230, 235 και 608 λόγω έργων ασφαλτόστρωσης στο Δήμο Ζωγράφου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.07.16 Αποζημίωση στους κατόχους καρτών απεριορίστων διαδρομών μηνός Ιουλίου λόγω 24 ωρης απεργίας των εργαζομένων στα ΜΜΜ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.07.16 Επαναφορά τυπικής διαδρομής στη γραμμή 1 τρόλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.07.16 Προσωρινή τροποποίηση διαδρομών γραμμών 230 και 608 λόγω ασφαλτόστρωσης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.07.16 Τροποποίηση διαδρομής λεωφορειακών γραμμών 307 308 και 411 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.07.16 Εφαρμογή θερινού προγράμματος ΙΙ για λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.07.16 Τροποπίηση διαδρομής λεωφορειακής γραμμής 235 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.07.16 Αναστολή λειτουργίας σχολικών γραμμών 242, 250 και Ε90 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.07.16 Αναταλλαγή εισιτηρίων περιόδου 01.09.2014 έως 31.01.2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.07.16 Λειτουργία ΜΜΜ την Τετάρτη 6-7-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.07.16 Λειτουργία ΜΜΜ την Τρίτη - την Τετάρτη 5 και 6 Ιουλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.16 Τροποποιήσεις λεωφ. γραμμών λόγω εκδήλωσης -"Λευκή νύχτα στο Μαρούσι-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.16 ΜΕΡΙΚΗ ΤΡΟΠΟΠΟΙΗΣΗ ΛΕΩΦ. ΓΡΑΜΜΗΣ 904 ΣΤΗΝ ΠΕΙΡΑΪΚΗ ΤΟΥ ΔΗΜΟΥ ΠΕΙΡΑΙΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.16 Θερινά δρομολόγια μέσων σταθερής τροχιάς (ΣΤΑ.ΣΥ) 2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.06.16 Τροποποίηση διαδρομής λεωφ. γραμμής 409 λόγω έργων (Συνέχεια προηγούμενης) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.06.16 Θερινά δρομολόγια για λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>23.06.16 Προσωρινή τροποποίηση διαδρομής της λεωφ. γραμμής 409 λόγω έργων  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>21.06.16 Λειτουργία ΜΜΜ την Τρίτη 21 Ιουνίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.06.16 Προσωρινή τροποποίηση διαδρομής της λεωφορειακής γραμμής 418 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.06.16 Έκτακτο πρόγραμμα δρομολογίων την ημέρα του Αγίου Πνεύματος Δευτέρα 20-6-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.06.16 Πρόσκληση προς τους Εργαζομένους στις Αστικές Συγκοινωνίες για απόσπαση στον ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.06.16 Έκτακτο: Αλλαγή ημερομηνίας στάσης εργασίας εργαζομένων στη ΣΤΑ.ΣΥ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>13.06.16 Τροποποίηση διαδρομής λεωφορειακών γραμμών 140 201 λόγω έργων στις οδούς Ηρώς Κωνσταντοπούλου και Κοτζιά στην Ηλιούπολη από 14-6-2016 έως και 15-7-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>09.06.16 ΜΕΡΙΚΗ ΤΡΟΠΟΠΟΙΗΣΗ ΛΕΩΦ. ΓΡΑΜΜΗΣ 915 ΣΤΟ ΛΟΦΟ ΒΩΚΟΥ ΔΗΜΟΥ ΠΕΙΡΑΙΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.06.16 Πρόσκληση για την Τακτική Γενική Συνέλευση των Μετόχων της Ο.Α.Σ.Α. Α.Ε. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.06.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών λόγω εορτής της Αναλήψεως του Κυρίου στο Δήμο Κρωπίας την Τετάρτη 8-6-2016 και την Πέμπτη 9-6-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.06.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών λόγω έργων στην οδό Σπύρου Δάβαρη στο Δήμο Κρωπίας έως τις 31-8-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.06.16 Αποζημίωση στους κατόχους εξαμηνιαίων και ετησίων καρτών απεριορίστων διαδρομών λόγω απεργίας των εργαζομένων στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.06.16 Στάσεις εργασίας στην ΣΤΑ.ΣΥ. από 6 έως 17 Ιουνίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>02.06.16 Λειτουργία ΜΜΜ την Κυριακή 05-06-2016 λόγω διεξαγωγής του νυκτερινού αγώνα δρόμου «Lighting Up Athens 5k Run» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>





<li class="collection-item"><a>27.05.16 Λειτουργία ΜΜΜ την Κυριακή 29-05-2016 λόγω της διεξαγωγής του αγώνα δρόμου «3ου ATTICA RUN - FUN Grand Prix» στο Δήμο Αθηναίων. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.05.16 Αποζημίωση στους κατόχους καρτών απεριορίστων διαδρομών μηνός Μαΐου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.05.16 Λειτουργία ΜΜΜ την Πέμπτη 26 Μαϊου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.05.16 Λειτουργία ΜΜΜ το Σάββατο και την Κυριακή 21 - 22 Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>18.05.16 Διαθέσιμο το OASA Telematics App σε android, iOS, Windows Phones </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.05.16 ΤΕΤΑΡΤΗ 18 ΜΑΙΟΥ - ΣΤΑΣΗ ΕΡΓΑΣΙΑΣ ΣΤΟΝ ΗΛΕΚΤΡΙΚΟ ΣΙΔΗΡΟΔΡΟΜΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>06.05.16 Απεργιακές κινητοποιήσεις στα ΜΜΜ Παρασκευή 6 και Σάββατο 7 Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.05.16 ΠΡΟΣΩΡΙΝΗ ΤΡΟΠΟΠΟΙΗΣΗ ΤΩΝ ΛΕΩΦ. ΓΡΑΜΜΩΝ 421, 619, Β9, Γ9 ΚΑΙ ΤΩΝ ΤΡΟΛΕΙ 3 ΚΑΙ 6, ΛΟΓΩ ΕΟΡΤΑΣΜΟΥ ΤΗΣ ΠΡΩΤΟΜΑΓΙΑΣ ΣΤΟ ΔΗΜΟ ΦΙΛΑΔΕΛΦΕΙΑΣ ΧΑΛΚΗΔΟΝΟΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.04.16 24 ωρη απεργία στις γραμμές 1, 2 και 3 του μετρό την Κυριακή του Πάσχα 1η Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.16 Δρομολόγια Λεωφορείων και τρόλλεϋ (Ο.ΣΥ.) κατά τη διάρκεια των εορτών του Πάσχα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.04.16 Δρομολόγια ΣΤΑ.ΣΥ. κατά τη διάρκεια των εορτών του Πάσχα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.04.16 Προσωρινή τροποποίηση των λεωφ. γραμμών 550 και 860 για την Κυριακή 24-4-2016 και από ώρα 06:00 έως 12:00, λόγω της διοργάνωσης του Διεθνούς Ημιμαραθώνιου της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.04.16 Λειτουργία ΜΜΜ την Κυριακή 17-4-2016 λόγω της διεξαγωγής του 23ου Ποδηλατικού Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.04.16 Τροποποιήσεις διαδρομών λεωφ. γραμμών λόγω του ποδηλατικού αγώνα -"KALLITHEA RUN-" του Δήμου Καλλιθέας την Κυριακή 17-04-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.04.16 Λειτουργία ΜΜΜ την Τετάρτη 13-04 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.04.16 Μεταφορά αφετηρίας γραμμής Χ96 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.04.16 ΤΕΛΙΚΟ ΠΡΟΓΡΑΜΜΑ METROSTAGES ΑΠΟ 1-4 ΕΩΣ ΚΑΙ 9-4-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.04.16 Τροποποίηση διαδρομών  γραμμών λόγω της διοργάνωσης του 2ου Αγώνα Δρόμου-«Δρόμοι Ελεύθεροι» του Δήμου Βύρωνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.03.16 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών σε διάφορους Δήμους λόγω παρελάσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.03.16 Λειτουργία Μέσων Σταθερής Τροχιάς την Πέμπτη 24-3-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.03.16 Τροποποιήσεις λεωφ. γραμμών λόγω των παρελάσεων της 24ης - 25ης Μαρτίου στο Δήμο της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.03.16 Ο Υπουργός ΥΠΟΜΕΔΙ κ. Χρήστος Σπίρτζης ανακοινώνει ότι ξεκινά από σήμερα η εφαρμογή της τηλεματικής και των «έξυπνων» στάσεων στα αστικά λεωφορεία και τρόλεϊ της Αττικής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.03.16 ΤΟ METROSTAGES ΚΑΝΕΙ ΠΡΕΜΙΕΡΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.03.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών λόγω αποκριάτικων εκδηλώσεων στους Δήμους Γλυφάδας, Αλίμου και Αργυρούπολης – Ελληνικού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.03.16 Λειτουργία Μέσων Σταθερής Τροχιάς την Πέμπτη 10-3-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.03.16 Τροποποίηση διαδρομών λεωφορειακών γραμμών και γραμμής τρόλεϊ λόγω αποκριάτικων εκδηλώσεων στο Δήμο Μοσχάτου-Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.03.16 ΦΩΤΟΓΡΑΦΙΚΑ ΝΤΟΚΟΥΜΕΝΤΑ ΤΗΣ ΚΑΤΟΧΗΣ ΣΕ 9 ΣΤΑΘΜΟΥΣ ΤΟΥ ΜΕΤΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.02.16 Λειτουργία Μέσων Σταθερής Τροχιάς την Τρίτη 1-3-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.02.16 Τροποποιήσεις λεωφορειακών γραμμών λόγω του ποδοσφαιρικού αγώνα ΑΕΚ - ΠΑΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.02.16 ΠΡΟΚΗΡΥΞΗ ΠΡΟΧΕΙΡΟΥ ΔΙΑΓΩΝΙΣΜΟΥ ΓΙΑ ΤΗΝ ΕΚΤΥΠΩΣΗ ΕΝΗΜΕΡΩΤΙΚΟΥ ΦΥΛΛΑΔΙΟΥ 2 ΟΨΕΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.02.16 TfA Trip Planner   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.02.16 Συμμετοχή των ΜΜΜ στις απεργιακές κινητοποιήσεις της Πέμπτης 4 Φεβρουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.01.16 Στάσεις εργασίας στα ΜΜΜ τη Τρίτη 2-2  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.01.16 Εκπτωτική πολιτική του ΟΑΣΑ για τη μαζική πώληση ετησίων και εξαμηνιαίων καρτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.01.16 Λειτουργία ΜΜΜ στις 21-01-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.01.16 Λειτουργία ΜΜΜ στις 20-01-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>19.01.16 Λειτουργία ΜΜΜ στις 19-01-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.01.16 ΕΠΑΝΑΦΟΡΑ ΛΕΩΦΟΡΕΙΑΚΗΣ ΓΡΑΜΜΗΣ 402 (ΣΤ. ΚΑΤΕΧΑΚΗ - ΠΟΛΥΔΡΟΣΟ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.01.16 Λειτουργία ΜΜΜ στις 12-01-2016 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.01.16 Τροποποιήσεις διαδρομών λεωφ. γραμμών στον Δήμο Κρωπίας (120, 308, 309, 330) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>05.01.16 Προσωρινή τροποποίηση  της διαδρομής της λεωφ. γραμμής  402 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.12.15 Λειτουργία ΜΜΜ την περίοδο των εορτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.12.15 προσωρινή τροποποίηση  διαδρομής της λεωφ. γραμμής  402 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.12.15 Στάση εργασίας στο μετρό και τραμ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.12.15 Τροποποίηση διαδρομής γραμμής 128 λόγω εκδηλώσεων επί της οδού Ζαμάνου στο Δήμο Γλυφάδας.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.12.15 Τροποποίηση διαδρομής γραμμής 800 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.12.15 Τροποποίηση διαδρομής 218 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.12.15 Συμμετοχή ΜΜΜ στην απεργία της Πέμπτης 3 Δεκεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.11.15 Λειτουργία ΜΜΜ την Κυριακή 29-11-2015 λόγω της διεξαγωγής του 2ου αγώνα δρόμου «ATHENS SANTA RUN» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.11.15 Έκπτωση στην έκδοση καρτών μηνός Δεκεμβρίου λόγω απεργιών του μηνός Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.11.15 Σε ισχύ η αποκλειστική λωρίδα λεωφορείων στην Ιερά Οδό (ΑΛΛ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.11.15 Προσωρινή τροποποίηση  της διαδρομής της λεωφ. γραμμής  402, για το χρονικό διάστημα από τις 7-10-2015 έως τις 31-12-2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.11.15 Κλειστοί σταθμοί μετρό λόγω του εορτασμού της 17ης Νοέμβρη </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.11.15 Λειτουργία ΜΜΜ από 06:00 της 15-11-2015 έως 06:00 της 18-11-2015: </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.11.15 Απεργιακές κινητοποιήσεις την Πέμπτη 12-11-2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>05.11.15 Επαναλειτουργία  λεωφορειακής γραμμής 024 με τροποποιημένη διαδρομή  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>04.11.15 Λειτουργία ΜΜΜ το Σάββατο 7-11-2015 και την Κυριακή 8-11-2015 λόγω του 33ου Αυθεντικού Μαραθωνίου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>03.11.15 Δωρεάν μετακίνηση συμμετεχόντων στο Μαραθώνιο Αθηνών και αλλαγή στην έναρξη των ωρών Κυκλοφορίας την Κυριακή 8 Νοεμβρίου 2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.11.15 Στάση εργασίας σε Μετρό, Ηλεκτρικό και Τραμ την Τρίτη 3 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.10.15 Αναστολή λειτουργίας γραμμής Χ80 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>29.10.15 Μεταφορά αφετηρίας λεωφορειακών γραμμών από πλ. Αναλήψεως στη Νίκαια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.10.15 Προσωρινή αναστολή λειτουργίας γραμμής 024 λόγω καθίζησης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>26.10.15 Συγκοινωνιακές τροποποιήσεις λόγω μαθητικών παρελάσεων στις 28-10-2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.10.15 Συγκοινωνιακές τροποποιήσεις λόγω εορτασμού 28ης Οκτωβρίου στον δήμο Φιλαδελφείας - Χαλκηδόνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>23.10.15 Συγκοινωνιακές τροποποιήσεις λόγω εορτασμού της 28ης Οκτωβρίου στον δήμο Ηρακλείου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.10.15 Τροποποιήσεις διαδρομών λεωφ. γραμμών στον Δήμο Πετρούπολης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>20.10.15 προσωρινή τροποποίηση των λεωφ. γραμμών 054, 140, 203, 204, 209 και της γραμμής τρόλεϊ 11 λόγω έργων στη Λεωφ. Χρυσοστόμου Σμύρνης του Δήμου Βύρωνα  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.15 Προσωρινή τροποποίηση γραμμών 054 209 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.15 Λειτουργία ΜΜΜ την Κυριακή 18-10-2015 λόγω της διεξαγωγής του 29ου Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.15 Συγκοινωνιακές τροποποιήσεις λόγω εορτασμού του Αγίου Αρτεμίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.15 Πρόσβαση στο αεροδρόμιο με το μετρό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.10.15 Διευκρινίσεις για τη δωρεάν μετακίνηση ανέργων (upd) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.10.15 Τροποποίηση διαδρομών στις γραμμές 825 871 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.10.15 Αναστολή ισχύος της απόφασης περι -"Συγκοινωνιακές τροποποιήσεις λόγω έργων στον Δήμο Βύρωνα-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>13.10.15 Προσωρινές τροποποιήσεις λεωφορειακών γραμμών στον Δήμο Παπάγου - Χολαργού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.10.15 Παράταση ισχύος εισιτηρίων παλαιών τιμών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>12.10.15 Συγκοινωνιακές τροποποιήσεις λόγω έργων στον Δήμο Βύρωνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.10.15 Συγκοινωνιακές αλλαγές στο Δήμο Αμαρουσίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>02.10.15 Tροποποίηση στις διαδρομές των γραμμών  404 και 308-307 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.15 Τροποποίηση διαδρομών λεωφορειακών γραμμών 203, 204, 212 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>02.10.15 Τροποποίηση διαδρομών λεωφορειακών γραμμών 130, 136 και 219   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.10.15 Τροποποίηση γραμμής 701 και δημιουργία συμπληρωματικής γραμμής 705 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>30.09.15 Μερική τροποποίηση διαδρομής της λεωφορειακής  γραμμής 829 (Τ.Ε.Ι. ΑΘΗΝΑΣ –  ΣΤ. ΑΙΓΑΛΕΩ – Τ.Ε.Ι. ΠΕΙΡΑΙΑ) στο Δήμο Αιγάλεω </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.15 Προσωρινή τροποποίηση της λεωφ. γραμμής 418 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>25.09.15 Λειτουργία ΜΜΜ την Κυριακή 27-9-2015 λόγω της διεξαγωγής του 7ου Αγώνα Δρόμου και Περιπάτου Greece Race for the Cure στο Δήμο Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>17.09.15 ΠΡΟΓΡΑΜΜΑ ΔΡΟΜΟΛΟΓΙΩΝ ΑΠΟ 18-9 ΕΩΣ 21-9-2015 ΚΑΤΑ ΤΗΝ ΠΕΡΙΟΔΟ ΕΚΛΟΓΩΝ  ΓΙΑ ΛΕΩΦΟΡΕΙΑ ΚΑΙ ΤΡΟΛΕΪ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>16.09.15 Συγκοινωνιακές ρυθμίσεις λόγω προεκλογικών συγκεντρώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>10.09.15 Συγκοινωνιακές ρυθμίσεις στο Δήμο Φιλοθέης – Ψυχικού  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>08.09.15 Χειμερινά δρομολόγια σε λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.08.15 Παράταση ισχύος των παλαιών εισιτηρίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>31.08.15 Κυκλοφοριακές ρυθμίσεις στην οδό Μακρυγιάννη του δήμου Μοσχάτου (αρχή Τετάρτη 2-9) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>28.08.15 Προσωρινή τροποποίηση διαδρομής γραμμής 051 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.08.15 Δρομολόγια Ιουλίου για λεοφωρεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>11.08.15 ΛΕΙΤΟΥΡΓΙΑ ΜΜΜ ΓΙΑ 15 ΑΥΓΟΥΣΤΟΥ 2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>27.07.15 Θερινά δρομολόγια Αυγούστου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>24.07.15 Προσωρινή τροποποίηση γραμμής 126 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.07.15 Φωτογραφικό ρεπορτάζ από τις εργασίες του 1ου Athens Hackathon 2015 #TRANSPORT </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>22.07.15 Κλειστοί οι σταθμοί μετρό -"ΣΥΝΤΑΓΜΑ-" - -"ΠΑΝΕΠΙΣΤΗΜΙΟ-" μετά τις 18:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>21.07.15 ΛΕΙΤΟΥΡΓΙΑ ΤΩΝ ΛΕΩΦΟΡΕΙΑΚΩΝ ΓΡΑΜΜΩΝ 242, E90 KAI 250 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>15.07.15 Κλειστός σταθμός του μετρό -"Σύνταγμα-" από 18:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>14.07.15 Λειτουργία ΜΜΜ την ετάρτη 15 Ιουλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>13.07.15 Δωρεάν μετακίνηση επιβατών με τα ΜΜΜ του Ομίλου ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>07.07.15 Παράταση του μέτρου δωρεάν μετακίνησης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>03.07.15 Θερινό πρόγραμμα δρομολογίων των Σταθερών Συγκοινωνιών  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.15 Δωρεάν μετακινήσεις μέχρι Τρίτη 6-7 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>01.07.15 Αλλαγή ημερομηνίας πραγματοποίησης του πρώτου Ελληνικού Hackathon 2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>4.06.15 Έναρξη θερινών δρομολογίων για λεωφορεία και τρόλεϊ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.15 ΤΡΟΠΟΠΟΙΗΣΗ ΠΡΟΓΡΑΜΜΑΤΟΣ ΔΡΟΜΟΛΟΓΙΩΝ ΤΩΝ ΓΡΑΜΜΩΝ Ε14 ΣΥΝΤΑΓΜΑ – ΟΑΚΑ-ΥΠ.ΠΑΙΔΕΙΑΣ» Χ14«ΣΥΝΤΑΓΜΑ – ΚΗΦΙΣΙΑ» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.15 ΑΝΑΣΤΟΛΗ ΛΕΙΤΟΥΡΓΙΑΣ ΤΗΣ ΛΕΩΦΟΡΕΙΑΚΗΣ ΓΡΑΜΜΗΣ 070 «ΓΗΡΟΚΟΜΕΙΟ-ΑΡ. ΠΑΓΟΣ-ΔΙΚΑΣΤ. ΕΥΕΛΠΙΔΩΝ» ΚΑΤΑ ΤΟΥΣ ΘΕΡΙΝΟΥΣ ΜΗΝΕΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>3.06.15 Λειτουργία ΜΜΜ την Τρίτη 23-6-2015 λόγω της διεξαγωγής του αγώνα δρόμου «SNFCC Run-Τρέχοντας προς το μέλλον» στο Δήμο Αθηναίων.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.06.15 Επαναφορά διαδρομής λεωφ. γραμμών 304 - 305 από την Λεωφ. Σπάτων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>0.05.15 Βραβείο Άριστης Επίδοσης για την Ολοκληρωμένη Στρατηγική Συγκοινωνιών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.05.15 Λειτουργία ΜΜΜ το Σάββατο 30-5-2015 λόγω της διεξαγωγής της εκδήλωσης «ΔΡΟΜΟΣ ΕΛΠΙΔΑΣ-ΠΟΤΕ ΠΙΑ ΝΑΖΙΣΜΟΣ» στο Δήμο Αθηναίων  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.05.15 Ενημέρωση για τα δρομολόγια τη Δευτέρα 1-6-2015 (Αγίου Πνεύματος) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.05.15 Προσωρινή τροποποίηση της λεωφορειακής γραμμής 409 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.05.15 Προσωρινή τροποποίηση  των  λεωφ. Γραμμών 444 , 410 και Α8 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.05.15 Παράταση ισχύος εισιτηρίων με παλαιές τιμές </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.05.15 Λειτουργία λεωφορειακών γραμμών περιοχής Εξαρχείων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.05.15 Οι Συγκοινωνίες Αθηνών αρωγός στο κοινωνικό έργο της Ιεράς Μητροπόλεως Νέας Ιωνίας - Φιλαδελφείας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.05.15 Λειτουργία ΜΜΜ την Τρίτη 12 Μαϊου  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>




<li class="collection-item"><a>4.05.15 Mερική προσωρινή τροποποίηση της λεωφ. γραμμής 409 λόγω έργων στο Δήμο Παπάγου-Χολαργού  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 ΕΠΑΝΑΛΕΙΤΟΥΡΓΙΑ ΛΕΩΦΟΡΕΙΑΚΗΣ ΓΡΑΜΜΗΣ Χ80 ΠΕΙΡΑΙΑΣ-ΑΚΡΟΠΟΛΗ-ΣΥΝΤΑΓΜΑ EXPRESS </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 Λειτουργία ΜΜΜ την 1η Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 Λειτουργία ΜΜΜ την Κυριακή 3-5-2015 λόγω της διεξαγωγής του Ημιμαραθωνίου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 Λειτουργία ΜΜΜ την Παρασκευή 1-5-2015 λόγω των εκδηλώσεων για τον εορτασμό της Εργατικής πρωτομαγιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 Λειτουργία ΜΜΜ κατά την Πρωτομαγιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.15 Στάση εργασίας στα τρόλλεϋ τη Τρίτη 28 Απριλίου 2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.04.15 Λειτουργία ΜΜΜ την Κυριακή 26-4-2015 λόγω της διεξαγωγής του 22ου Ποδηλατικού Γύρου της Αθήνας. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.04.15 Μερική τροποποίηση διαδρομής λεωφ. γραμμών 550 860 λόγω αγώνα δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>
<li class="collection-item"><a>6.05.15 Συμμετοχή του ΟΑΣΑ στο Συμβούλιο Αστικών Συγκοινωνιών Θεσσαλονίκης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.15 Μερική προσωρινή τροποποίηση λεωφ. γραμμών 421 619 Β9 Γ9 και γραμμών τρόλλεϋ 3 - 6 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.15 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών λόγω 3ου IVE WELL EVENT </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.15 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών στον Δήμο της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.04.15 Τροποποίηση διαδρομών λεωφορειακών γραμμών Δήμου Αχαρνών λόγω εορτασμού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.04.15 Eνημερώση για τα δρομολόγια της γραμμής Ε14 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.04.15 Eνημερώση δρομολογίων Μ.Σαββάτου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.15 Επαναφορά κανονικής διαδρομής λεωφορειακών γραμμών 300 - 904 του Δήμου Πειραιά. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.04.15 Προγράμματα και ώρες λειτουργίας των ΜΜΜ κατά τις εορτές του Πάσχα 2015 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.04.15 Τροποποίηση διαδρομης γραμμών 300 - 904 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.04.15 Προσωρινή τροποποίηση λεωφορειακών γραμμών στο Δήμο Καλλιθέας λόγω αγώνα δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.04.15 Παράταση ισχύος εισιτηρίων με παλαιές τιμές </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.03.15 Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.03.15 Φιλικός ποδοσφαιρικός αγώνας για ΦΙΛΑΝΘΡΩΠΙΚΟΥΣ ΣΚΟΠΟΥΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>4.03.15 ΔΙΕΥΚΡΙΝΙΣΤΙΚΕΣ ΑΠΑΝΤΗΣΕΙΣ ΕΠΙ ΤΩΝ ΕΡΩΤΗΜΑΤΩΝ ΔΙΑΓΩΝΙΣΜΟΥ 11185 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.15 Κυκλοφοριακές ρυθμίσεις λόγω παρελάσεων της 25ης Μαρτίου στους Δήμους της Αττικής από 24 - 25 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.03.15 Τροποποίηση διαδρομών λεωφορειακών γραμμών στον Δήμο Βύρωνα λόγω αγώνα δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.03.15 Πέμπτη 19 Μαρτίου: Στάση εργασίας στο μετρό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.03.15 Λειτουργία προσωρινής γραμμής Χ1 ΣΤ. ΠΕΙΡΑΙΑ - ΣΤ. ΦΑΛΗΡΟ για τις ώρες και ημέρες διακοπής λειτουργίας του Ηλεκτρικού Σιδηροδρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.15 Μεταφορά γραφείου διαχείρισης προστίμων ΣΤΑ.ΣΥ. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.15 Τροποποίηση γραμμής τρόλλεϋ 20 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.15 Στάση εργασίας στα Λεωφορεία  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.15 Τροποποιήσεις διαδρομών λεωφορειακών γραμών λόγω καρναβαλικών εκδηλώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων  19-02-15 (08:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων  19-02-15 (1) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.02.15 Καθυστερήσεις δρομολογίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.02.15 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών λόγω αποκριάτικων εκδηλώσεων  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.15 Προβλήματα στα ΜΜΜ (λεωφορεία) λόγω χιονοπτώσεων (Ενημέρωση 07:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.15 Διακοπή κυκλοφορίας στον παράδρομο της Κηφισίας λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.15 Τροποποίηση διαδρομής λεωφορειακής γραμμής 046 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.01.15 Δρομολόγια γραμμής Ε14 στις 23 - 26 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.01.15 Τροποποιήσεις διαδρομών λεωφ. γραμμών λόγω προεκλογικών συγκεντρώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.01.15 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής  306 λόγω έργων αποχέτευσης  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.15 ΠΡΟΓΡΑΜΜΑ ΔΡΟΜΟΛΟΓΙΩΝ ΚΑΤΑ ΤΗΝ ΠΕΡΙΟΔΟ ΕΚΛΟΓΩΝ 25-1-2015 ΓΙΑ ΛΕΩΦΟΡΕΙΑ ΚΑΙ ΤΡΟΛΕΪ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.01.15 MΕΤΡΟ: Διακοπή δρομολογίων στο τμήμα Εθνική Άμυνα-Αεροδρόμιο από 22:00 μέχρι τη λήξη της κυκλοφορίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>9.01.15 Λεωφορειακές γραμμές Εξαρχείων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.15 Προβλήματα στα ΜΜΜ λόγω παγετού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.15 Προβλήματα λειτουργίας λεωφορειακών γραμμών λόγω παγετου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.01.15 Ενημέρωση σχετικά με τα προβλήματα σε λεωφορειακές γραμμές από παγετό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.01.15 Προβλήματα στα ΜΜΜ λόγω καιρικών συνθηκών (συνέχεια) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.01.15 Προβλήματα λειτουργίας σε λεωφορειακές γραμμές λόγω καιρικών συνθηκών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.14 Προβλήματα στις μετακινήσεις με τα ΜΜΜ λόγω καιρικών συνθηκών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.12.14 Αυτόματο Σύστημα Συλλογής Κομίστρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.12.14 Ψήφισμα για τον θάνατο του Δημητρίου Τσαμπούλα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.14 Ενημέρωση για δρομολόγια Εξαρχείων και για νυχτερινές γραμμές 040, 11 και χ14 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.12.14 ΣΤΑ.ΣΥ.  -   ΣΥΧΝΟΤΗΤΕΣ ΔΙΕΛΕΥΣΗΣ ΣΥΡΜΩΝ ΕΟΡΤΑΣΤΙΚΩΝ  ΔΡΟΜΟΛΟΓΙΩΝ 2014-2015  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.12.14 Πρόγραμμα δρομολόγησης Ο.ΣΥ(λεωφορεία και τρόλεϊ) κατά τη περίοδο των εορτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.12.14 «ΛΙΓΟ ΓΑΛΑ ΓΙΑ ΠΟΛΛΑ ΠΑΙΔΙΑ» Απολογισμός δράσης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.14 Λειτουργία ΜΜΜ από 10:00’ ώρα της 6-12-2014 έως 07:00’ της 7-12-2014 λόγω των κυκλοφοριακών ρυθμίσεων της ΕΛ. ΑΣ.  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.14 Λειτουργία ΜΜΜ την Κυριακή 7-12-2014 λόγω της διεξαγωγής του 1ου αγώνα δρόμου «ATHENS SANTA RUN» </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.14 Αναστολή λειτουργίας γραμμής Χ80 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.14 Τροποποίηση διαδρομής λεωφορειακής γραμμής 306 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.12.14 Τροποποίηση διαδρομής γραμμών 304 - 305 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.12.14 «ΛΙΓΟ ΓΑΛΑ ΓΙΑ ΠΟΛΛΑ ΠΑΙΔΙΑ» ΓΡΑΜΜΑ ΣΤΟΝ Αϊ ΒΑΣΙΛΗ ΑΠΟ ΤΟΥΣ ΓΙΑΤΡΟΥΣ ΤΟΥ ΚΟΣΜΟΥ ΚΑΙ ΤΙΣ ΣΥΓΚΟΙΝΩΝΙΕΣ ΑΘΗΝΩΝ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.11.14 Μερικές τροποποιήσεις λεωφορειακών γραμμών 122 - Α3 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.11.14 Λειτουργία ΜΜΜ την Πέμπτη 27-11-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.11.14 Ειδικό βραβείο -"Public Management Best Practices Award-" απενεμήθη στις Συγκοινωνίες Αθηνών  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.11.14 Λειτουργία ΜΕΤΡΟ τη Δευτέρα 17-11-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.11.14 Λειτουργία ΜΜΜ στις 17 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.11.14 Λειτουργία ΜΜΜ από 06:00 της 15-11-2014 έως 06:00 της 18-11-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.11.14 Τροποποιήσεις στο δίκτυο λεωφορείων από 10-11-2014 στα Νότια προάστια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.11.14 Λειτουργία ΜΜΜ το Σάββατο 8-11-2014 και την Κυριακή 9-11-2014 λόγω του 32ου Αυθεντικού Μαραθωνίου Αθηνών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.11.14 Συνέντευξη του Προέδρου του ΟΑΣΑ σε φοιτητικό site </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>1.10.14 Απολογισμός του συνεδρίου των ταξιδιωτικών bloggers στην Αθήνα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.10.14 Τροποποίηση διαδρομής γραμμής 307 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.10.14 Μερική τροποποίηση διαδρομών γραμμών λόγω αγώνα δρόμου στον δήμο Ζωγράφου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.10.14 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ την ΠΕΜΠΤΗ 30-10-2014. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.10.14 ΤΒΕΧ 2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.10.14 Λειτουργία ΜΜΜ στις 28-10-2014 λόγω των μαθητικών παρελάσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.10.14 ΛΕΙΤΟΥΡΓΙΑ ΟΣΥ ΓΙΑ 27 ΚΑΙ 28 ΟΚΤΩΒΡΙΟΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.10.14 Κυκλοφοριακές ρυθμίσεις λόγω του αγώνα CITY RUN στον Πειραιά την Κυριακή 19-10-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>




<li class="collection-item"><a>7.10.14 Προσωρινή τροποποίηση διαδρομής λεωφορειακής γραμμής 406 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.10.14 Προσωρινή τροποποίηση διαδρομής λεωφορειακής γραμμής 406 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.10.14 Ισχύς ετησίων καρτών παλαιών τιμών. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.09.14 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ την ΤΕΤΑΡΤΗ 24-9-2014. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.09.14 Λειτουργία των τρόλλεϋ τη Τρίτη 23-09-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.09.14 Λειτουργία Σταθμού ΜΕΤΡΟ ΣΥΝΤΑΓΜΑ την 19.9.2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.09.14 Μερική τροποποίηση διαδρομών γραμμών 054, 605 λόγω εορτασμού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.09.14 Μερική τροποποίηση διαδρομής γραμμής 418 λόγω εκδηλώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.09.14 Λειτουργία Σταθμού ΜΕΤΡΟ ΠΑΝΕΠΙΣΤΗΜΙΟ την 16.9.2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>6.09.14 Τροποποιήσεις λειτουργίας Ηλεκτρικού Σιδηροδρόμου την Παρασκευή 19-9-2014 λόγω συναυλίας στο ΟΑΚΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.09.14 Λειτουργία γραμμής 070 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.09.14 Προσωρινή τροποποίηση γραμμών 036, 140, 402 λόγω εορτασμού στον Ι.Ν Αγ. Σοφίας στο Δήμο Φιλοθέης - Ψυχικού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.09.14 Χειμερινά δρομολόγια σε λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.09.14 Νέα δρομολόγια στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.08.14 Μερική προσωρινή τροποποίηση γραμμών 406 - 407 λόγω έργων στην οδό Παπαρρηγοπούλου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.08.14 ΛΕΙΤΟΥΡΓΙΑ ΤΩΝ ΛΕΩΦΟΡΕΙΑΚΩΝ ΓΡΑΜΜΩΝ 242 ΚΑΙ 250  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.08.14 ΛΕΙΤΟΥΡΓΙΑ ΜΜΜ ΓΙΑ 15 ΑΥΓΟΥΣΤΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών στο Δήμο Κρωπίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Προσωρινή τροποποίηση διαδρομής γραμμών 833 - 835 στους Δήμους Πειραιά, Κερατσινίου - Δραπετσώνας λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Θερινά δρομολόγια Ο.ΣΥ. Αυγούστου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.07.14 Τροποποιήσεις διαδρομών λεωφ. γραμμών Δήμου Κηφισιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.07.14 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών στο Δήμο Κρωπίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.07.14 Τροποποίηση διαδρομής λεωφ. γραμμής 535 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Τροποποίηση διαδρομής γραμμής 411 λόγω αντιπλημμυρικών έργων στη Σισμανογλείου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Τροποποίηση διαδρομής γραμμής 813 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Τροποποίηση διαδρομής 051 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.07.14 Οι Συγκοινωνίες Αθηνών σας προσκαλούν στη βράβευση των νικητών του διαγωνισμού φωτογραφίας -"είσαι μέσα-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Ανακοίνωση αποτελεσμάτων διαγωνισμού φωτογραφίας «Είσαι Μέσα» (Αφορά βραβευθείσες φωτογραφίες) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.07.14 ΑΠΟΤΕΛΕΣΜΑΤΑ ΚΛΗΡΩΣΗΣ ΔΙΑΓΩΝΙΣΜΟΥ -"ΕΙΣΑΙ ΜΕΣΑ - ΟΑΣΑ-" (Η κλήρωση αφορά όσους έκαναν like στις φωτογραφίες του διαγωνισμού) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.07.14 Θερινό πρόγραμμα δρομολογίων των Σταθερών Συγκοινωνιών  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.14 Παράταση τροποποίησης διαδρομών γραμμών στο Δήμο Αθηναίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.06.14 Μερική τροποποίηση διαδρομής γραμμής 406 στο Δήμο Αγ. Παρασκευής  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.14 Μεταφορά αφετηριών γραμμών 300 και 904 στο Δήμο Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.14 Αναστολή λειτουργίας γραμμής 070 για την θερινή περίοδο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.14 Έναρξη θερινών δρομολογίων για λεωφορεία και τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.06.14 ροσωρινή τροποποίηση διαδρομών τρόλλεϋ στην οδό Κρίσσης λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.14 Στάση εργασίας στα τρόλλεϋ λόγω Γενικής Συνέλευσης των Εργαζομένων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.06.14 Μερική τροποποίηση διαδρομής λεωφορειακών γραμμών 527, 642 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.06.14 Εξυπηρέτηση θεατών εκδήλωσης MAD TV VIDEO MUSIC AWARDS 2014  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.06.14 Ψήφισμα Διοικητικού Συμβουλίου ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.14 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών στο Δήμο Ηλιούπολης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>3.06.14 Μερική τροποποίηση διαδρομών λεωφορειακών γραμμών στο Δήμο Δάφνης - Υμηττού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.06.14 Ενημέρωση για δρομολόγια τη Δευτέρα 9-6-2014 (Αγίου Πνεύματος) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.05.14 Ενίσχυση δρομολογίων Αεροδρομίου και γραμμών που εξυπηρετούν παραθαλάσσιες περιοχές </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.05.14 Λειτουργία ΤΡΑΜ στις 28 - 28 Μαϊου 2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.05.14 Τροποποίηση νυκτερινών δρομολογίων για την περίοδο των εκλογών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.05.14 Μερική τροποποίηση γραμμών την Πέμπτη 15-05-2014 από 19:00 - 22:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.05.14 Πρόγραμμα Δρομολόγησης λεωφορείων - τρόλλεϋ κατά την εκλογική περίοδο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.05.14 Πληροφορίες για τη νέα λεωφ. γραμμή Χ80 ΠΕΙΡΑΙΑΣ-ΑΚΡΟΠΟΛΗ-ΣΥΝΤΑΓΜΑ EXPRESS  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.05.14 Μερική τροποποίηση διαδρομής γραμμών 203, 204 - τρόλλεϋ 11 λόγω Πολιτικής ομιλίας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.05.14 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 447 στο Δήμο Βριλησσίων λόγω αντιπλημμυρικών έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.14 Λειτουργία ΜΜΜ την 1η Μαϊου (11:43) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.04.14 Λειτουργία ΜΜΜ την 1η Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.04.14 Τροποποιήσεις λεωφορειακών γραμμών στο Δήμο Ν. Φιλαδέλφειας - Χαλκηδόνος λόγω του εορτασμού της Πρωτομαγιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.04.14 Προσωρινή μερική τροποποίηση των διαδρομών των γραμμών 140, 212, 856 λόγω έργων(Οι γραμμές λειτουργούν στις κανονικές διαδρομές τους λόγω μη έναρξης των προγραμματισμένων εργασιών.) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.04.14 Τροποποίηση λεωφορειακών γραμμών λόγω του αγώνα Τελικού Κυπέλου Ελλάδος  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.04.14 Προσωρινή τροποποίηση 550, 860 λόγω αγώνα διεθνούς Ημιμαραθώνιου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>4.04.14 Μερική τροποποίηση διαδρομών γραμμών 218, 232, 860 και τρόλλεϋ 1 λόγω εγκαινίων εκλογικού κέντρου στο Δήμο Μοσχάτου - Ταύρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.04.14 Λειτουργία Σταθμών ΜΕΤΡΟ ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ, ΕΥΑΓΓΕΛΙΣΜΟΣ, ΚΑΤΕΧΑΚΗ, ΣΥΝΤΑΓΜΑ - ΑΚΡΟΠΟΛΗ την 11.4.2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.14 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών λόγω αγώνα δρόμου στο Δήμο Καλλιθέας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.04.14 Κλειστός ο σταθμός Μετρό -"ΣΥΝΤΑΓΜΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.04.14 Λειτουργία ΜΜΜ κατά την διάρκεια της απεργίας της Τετάρτης 9 Απριλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.04.14 Τροποποίηση διαδρομής λεωφορειακής γραμμής 447  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.14 Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.04.14 Προγράμματα και ώρες λειτουργίας των ΜΜΜ κατά τις εορτές του Πάσχα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.04.14 Προσωρινή διακοπή λειτουργίας γραμμής 653 λόγω αγώνα δρόμου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.04.14 Μερική τροποποίηση διαδρομής γραμμής 302 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.04.14 Τροποποίηση διαδρομής λεωφορειακής γραμμής 051 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.04.14 Κλειστοί σταθμοί του Μετρό το απόγευμα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.03.14 Επέκταση ειδικού πειραματικού προγράμματος λειτουργίας λεωφορειακών γραμμών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.14 Ανοικτός ο σταθμός Μετρό ΣΥΝΤΑΓΜΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.14 Μετάθεση ημερομηνίας διενέργειας πρόχειρου διαγωνισμούγια την  εγκατάσταση και λειτουργία τερματικών POS αποδοχής καρτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.14 Λειτουργία Σταθμού ΜΕΤΡΟ ΣΥΝΤΑΓΜΑ την 24 - 25.3.2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.03.14 Κυκλοφοριακές ρυθμίσεις λόγω παρελάσεων της 25ης Μαρτίου στους Δήμους της Αττικής από 24 - 26 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.03.14 Λειτουργία ΜΜΜ την περίοδο 24 - 26 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.03.14 10ο Ευρωπαϊκό Συνέδριο Ευφυών Συστημάτων Μεταφορών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.03.14 Κυκλοφοριακές ρυθμίσεις λόγω της 25ης Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.14 Ενημέρωση για τις κυκλοφοριακές ρυθμίσεις στον Πειραιά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.03.14 Προσωρινή τροποποίηση γραμμής 604 από 07-03-2014 έως 23-03-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.03.14 Κλειστός ο σταθμός Μετρό -"ΣΥΝΤΑΓΜΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.03.14 Στάση εργασίας στα ΤΡΟΛΛΕΥ από 12:00 έως 17:00 την Τετάρτη 5 Μαρτίου λόγω Γενικής Συνέλευσης των Εργαζομένων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.14 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών λόγω Αποκριάτικων Εκδηλώσεων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.14 Στάση εργασίας στον Προαστιακό Σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.14 Μερική τροποποίηση γραμμής 024 για το διάστημα 05-03-2014-05-04-2014 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.02.14 ΑΝΑΚΟΙΝΩΣΗ ΓΙΑ ΤΗΝ ΓΡΑΜΜΗ ΤΡΟΛΕΙ 17 - ΝΕΑ μερική τροποποίηση από τις 25-02-2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.14 Μερική τροποποίηση γραμμών τρόλλεϋ 17 και 20 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.14 Τροποποίηση διαδρομής γραμμής 302 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.14 Μερική προσωρινή τροποποίηση της διαδρομής της πρότυπης λεωφ. γραμμής Α8,  λόγω εργασιών  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.14 Συγκοινωνιακές ρυθμίσεις στον Πειραιά λόγω επέκτασης του ΤΡΑΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.14 Λειτουργία προσωρινής λεωφορειακής γραμμής Χ5 «ΣΤ. ΕΘΝ. ΑΜΥΝΑΣ – ΣΤ. ΔΟΥΚ. ΠΛΑΚΕΝΤΙΑΣ» για τo Σάββατο και την Κυριακή 15 και 16 Φεβρουαρίου 2014 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.14 Γραφείο πληρωμής προστίμων Ο.ΣΥ. στην Πλατεία Αττικής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.14 Επέκταση ειδικού πειραματικού προγράμματος λειτουργίας λεωφορειακών γραμμών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.02.14 Κλειστός ο σταθμός Μετρό -"ΣΥΝΤΑΓΜΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.14 Τροποποίηση γραμμής 024 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.14 Ενοποίηση γραμμών 508 και 509 σε νέα γραμμή 509 ΖΗΡΙΝΕΙΟ-ΑΓ.ΣΤΕΦΑΝΟΣ-ΚΡΥΟΝΕΡΙ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.14 Τροποποιήσεις διαδρομών λεωφορειακών γραμμών 154, Α4 και Β1 λόγω έργων  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.14 Στάση εργασίας στα ΤΡΟΛΛΕΥ από 12:00 έως 16:00 την Πέμπτη 9 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.14 Κλειστός ο σταθμός μετρό -"ΜΕΓΑΡΟ ΜΟΥΣΙΚΗΣ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.01.14 Οριστική διακοπή λειτουργίας 185 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.13 Τροποποίηση - μετονομασία γραμμής Χ63 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.13 Πρόσληψη 200 ελεγκτών κομίστρου στον ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.13 Τελευταία δρομολόγια λεωφορείων - τρόλλεϋ στις 31-12-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.13 ΕΠΑΝΑΠΡΟΚΗΡΥΞΗ ΠΡΟΧΕΙΡΟΥ ΔΙΑΓΩΝΙΣΜΟΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.12.13 Λειτουργία Τηλεφωνικού Κέντρου (11185) κατά τις ημέρες των εορτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.12.13 Πρόγραμμα  δρομολόγησης Ο.ΣΥ. κατά τη περίοδο των εορτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>0.12.13 ΑΠΑΣΧΟΛΗΣΗ 200 ΕΛΕΓΚΤΩΝ ΚΟΜΙΣΤΡΟΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.12.13 Συχνότητα δρομολογίων - πρώτα - τελευταία δρομολόγια Μέσων Σταθερής τροχιάς κατά την περίοδο των εορτών των Χριστουγέννων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.12.13 Πρόχειρος διαγωνισμός  ασφαλιστικής κάλυψης περιουσιακών στοιχείων ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.12.13 Πρόχειρος διαγωνισμός  ασφαλιστικής κάλυψης περιουσιακών στοιχείων ΟΑΣΑ - Πλήρες τεύχος </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.12.13 Πρόχειρος διαγωνισμός  ασφαλιστικής κάλυψης περιουσιακών στοιχείων ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.12.13 Πίνακας Πρόσληψης από το Πρόγραμμα Κοινωφελούς Χαρακτήρα σε επιβλέποντες φορείς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.12.13 Επέκταση ειδικού πειραματικού προγράμματος λειτουργίας λεωφορειακών γραμμών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.12.13 Κλειστοί σταθμοί του ΜΕΤΡΟ από 10:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.11.13 Λειτουργία προσωρινής λεωφορειακής γραμμής με ονομασία X50 «ΣΤ. ΣΥΝΤΑΓΜΑ - ΣΤ. ΑΙΓΑΛΕΩ» τη Κυριακή 24-11-13 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.11.13 Επαναφορά τυπικών διαδρομών σε λεωφ. γραμμές στους Δήμους Πειραιά και Νίκαιας- Α.Ι.Ρέντη από  22-11-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.11.13 ΠΡΟΣΟΧΗ: Οδηγίες προς τους Επιβάτες για την αποφυγή αγοράς πλαστών εισιτηρίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.11.13 Προσωρινές τροποποιήσεις στα ΜΜΜ λόγω του εορτασμού του Πολυτεχνείου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.11.13 Λειτουργία προσωρινής γραμμής Χ50 για την Παρασκευή 15 - Σάββατο 16 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.11.13 Τροποποίηση λεωφ. γραμμής 653 λόγω έργων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.11.13 Τροποποίηση διαδρομής 304 - 305 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.11.13 Κυκλοφοριακές ρυθμίσεις λόγω της διεξαγωγής του Κλασικού Μαραθώνιου της Αθήνας (Κυριακή 9-11-2013) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.11.13 ANAKOINΩΣΗ ΓΙΑ ΓΡΑΜΜΗ Χ50 856, ΓΙΑ 9 - 10-11 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.11.13 Αποκατάσταση προβλήματος στον Ηλεκτρικό Σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.11.13 Έκτακτη ανακοίνωση για λειτουργία Ηλεκτρικού Σιδηρόδρομου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.11.13 Απεργιακές κινητοποιήσεις στα ΜΜΜ στις 5 - 6 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.10.13 Ενοποίηση λεωφορειακών γραμμών 306 - 324 σε 306 με νέα διαδρομή </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.10.13 Αλλαγή αριθμού κλήσεως τηλεφωνικού κέντρου ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.10.13 Δημιουργία προσωρινής λεωφορειακής γραμμής -"Στ. Σύνταγμα - Στ. Αιγάλεω-" Χ50 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.10.13 Τροποποίηση λεωφ. γραμμής Α8 την Δευτέρα 28-10-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.10.13 Δεν πραγματοποιήθηκε η αλλαγή αριθμού κλήσεως του τηλεφωνικού κέντρου του ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.10.13 Συγκοινωνιακές ρυθμίσεις λόγω αγώνα Μαραθώνιου στους Δήμους Φιλοθέης και Ψυχικού </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.10.13 Σημαντική ανακοίνωση </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.10.13 Τροποποίηση λόγω έργων στη γραμμή 302 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.10.13 ΚΑΝΕ ΤΟ ΣΩΣΤΟ ΣΥΝΔΥΑΣΜΟ Επιλογές μετακίνησης – Επιλογές ζωής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.10.13 Στάση εργασίας στα ΤΡΟΛΛΕΥ από 12:00 έως 16:00 την Τρίτη 8 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.10.13 Τροποποιήσεις λεωφ. γραμμών στους Δήμους Πειραιά και Νίκαιας- Α.Ι.Ρέντη  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>5.09.13 Κλειστοί σταθμοί του Μετρό την Τετάρτη 25 Σεπτεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.09.13 Κλειστός ο σταθμός Μετρό -"ΣΥΝΤΑΓΜΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.09.13 Ειδικό πειραματικό πρόγραμμα λειτουργίας λεωφορειακών γραμμών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.09.13 Κλειστός ο σταθμός Μετρό -"ΣΥΝΤΑΓΜΑ-" </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.09.13 Στάση Εργασίας ΓΣΕΕ την Τετάρτη 18 Σεμπτεβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.09.13 Νυκτερινά δρομολόγια Χ97  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.08.13 Αλλαγή δρομολογίων ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.08.13 Λειτουργία ΜΜΜ  για τον 15Αύγουστο. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.08.13 Νέα δρομολόγια για τις γραμμές Χ97 - 205 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>9.07.13 Εφαρμογή δρομολογίων Αυγούστου για λεωφορεία και τρόλεϊ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.07.13 Λειτουργία νέων σταθμών ΜΕΤΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.07.13 Οι Συγκοινωνιακές ρυθμίσεις λόγω της επέκτασης του μετρό στα Νότια Προάστια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.07.13 Οι νέες διαδρομές των λεωφορειακών γραμμών που τροποποιούνται με τη λειτουργία των νέων σταθμών Μετρό στα Νότια Προάστια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.07.13 Αγόρασε και επικύρωσε το εισιτήριό σου, μην «ακυρώνεις» τις μετακινήσεις σου” </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.07.13 Κλειστοί σταθμοί του Μετρό την Τρίτη 16 Ιουλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.07.13 Απεργιακές κινητοποιήσεις στα ΜΜΜ την Τρίτη 16 Ιουλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.07.13 Λειτουργία του σταθμού μετρό ΑΓΙΟΣ ΔΗΜΗΤΡΙΟΣ- ΑΛ. ΠΑΝΑΓΟΥΛΗΣ  την Παρασκευή 12-7-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>8.06.13 Αλλαγές δρομολογίων των γραμμών τρόλεϊ 7 και 8 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.13 Θερινό πρόγραμμα δρομολογίων Μέσων Σταθερής Τροχιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.13 Στάση εργασίας στα ΤΡΟΛΛΕΥ από 12:30 έως 15:30 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.06.13 ΑΝΟΙΚΤΗ ΠΡΟΣΚΛΗΣΗ ΣΥΝΕΡΓΑΣΙΑΣ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.13 Κλειστός ο Σταθμός -"Αγ. Δημήτριος-" του Μετρό λόγω δοκιμών επέκτασης για το Σ-Κ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.13 Συγκοινωνιακές ρυθμίσεις στον Δήμο Ηλιούπολης για την Κυριακή 16 Ιουνίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.06.13 Απεργιακές κινητοποιήσεις στα ΜΜΜ (18:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.06.13 Απεργιακές κινητοποιήσεις στα ΜΜΜ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.13 ΠΡΟΣΚΛΗΣΗ ΤΑΚΤΙΚΗΣ ΓΕΝΙΚΗΣ ΣΥΝΕΛΕΥΣΗΣ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.13 Δημιουργία προσωρινής λεωφ. γραμμής μεταξύ Στ. Μετρό Δάφνης  - Στ. Μετρό Αγ. Δημητρίου για το Σ-Κ 8 - 9 Ιουνίου λόγω δοκιμών στους σταθμούς Μετρό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.13 Πιθανό πρόβλημα διαθεσιμότητας του site </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.05.13 ΑΝΑΚΟΙΝΩΣΗ ΓΙΑ ΤΟΥΣ ΕΘΕΛΟΝΤΕΣ ΤΟΥ ΕΡΓΟΥ ENERQI </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.05.13 Συγχώνευση λεωφορειακών γραμμών και δημιουργία νέας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.05.13 Μεταφορά αφετηριών λεωφορειακών γραμμών στο κέντρο της Αθήνας </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.05.13 Τεχνικό πρόβλημα απεικόνισης λεωφορειακών γραμμών στους χάρτες google  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.05.13 Μερική προσωρινή τροποποίηση των λεωφ. γραμμών 421, Β8,  Β9, Γ9 και των  τρόλεϊ 3 και 6  λόγω των εορταστικών εκδηλώσεων για τον εορτασμό της Πρωτομαγιάς στο Δήμο Ν. Φιλαδέλφειας - Χαλκηδόνος </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.04.13 Αναστολή δρομολογίων γραμμών 7 - 8 (τρόλλεϋ) και 060 - 404 τις Κυριακές </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.04.13 Ενοποίηση λεωφορειακών γραμμών 641 - 642 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.04.13 Μεταφορά αφετηριών και τροποποίηση διαδρομής λεωφ. γραμμών Α10 και Β10 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>3.04.13 Μερική προσωρινή τροποποίηση της λεωφ. γραμμής 406 λόγω έργων στο Δήμο Αγ. Παρασκευής </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.04.13 Μερική προσωρινή τροποποίηση των λεωφορειακών γραμμών   651 (Ψυχικό – Πανόρμου Α) και 036 (Στ. Κατεχάκη – Στ. Πανόρμου- Γαλάτσι-Κυψέλη) λόγω εργασιών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.03.13 Λειτουργία Σταθμού ΜΕΤΡΟ ΣΥΝΤΑΓΜΑ την Παρασκευή 29.03.2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.03.13 Καθορισμός εκπτώσεων στις τιμές πώλησης των μηνιαίων καρτών απεριορίστων διαδρομών Απριλίου 2013 λόγω απεργιακών κινητοποιήσεων   </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.03.13 Λειτουργικές μεταβολές στο δίκτυο ΣΤΑΣΥ - ΗΣΑΠ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.03.13 Κλειστός ο σταθμός μετρό Αγ. Αντωνίου το Σ-Κ 16 - 17 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.03.13 Τροποποίηση διαδρομής λεωφορειακής γραμμής 719 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.02.13 Προσωρινή ίδρυση λεωφορειακής γραμμής στο Δήμο Αγ. Δημητρίου και ενίσχυση δρομολογίων της γραμμής τρόλεϊ 12 και της λεωφορειακής γραμμής Α13 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.13 Λειτουργία ΜΜΜ την Τετάρτη 20 Φεβρουαρίου (18:15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.13 Λειτουργία ΜΜΜ την Τετάρτη 20 Φεβρουαρίου (11:15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.13 Λειτουργία ΜΜΜ την Τετάρτη 20 Φεβρουαρίου (07:45) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.13 Λειτουργία ΜΜΜ την Τρίτη 19 Φεβρουαρίου - Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.02.13 Πέμπτη 14 Φεβρουαρίου - Στάση εργασίας στα μπλε λεωφορεία </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.02.13 Στάση εργασίας σε λεωφορεία, τρόλεϊ και προαστιακό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.13 Λειτουργία ΜΜΜ την Πέμπτη 31 Ιανουαρίου (renew 18.30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.13 Λειτουργία ΜΜΜ την Πέμπτη 31 Ιανουαρίου (renew 13.30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.13 Λειτουργία ΜΜΜ την Πέμπτη 31 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.13 Λειτουργία ΜΜΜ την Τετάρτη 30-01-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.13 Λειτουργία των ΜMM την Τρίτη 29-01-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.01.13 Λειτουργία ΜΜΜ στις 25 - 01 -  2013  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.01.13 Λειτουργια ΜΜΜ την Πέμπτη 24-01-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.01.13 Λειτουργία ΜΜΜ την Τετάρτη 23 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.01.13 Λειτουργία ΜΜΜ την Τρίτη 22 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>1.01.13 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ τη ΔΕΥΤΕΡΑ 21-1-2013. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.13 Λειτουργία του ΜΕΤΡΟ την ΚΥΡΙΑΚΗ 20-1-2013. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.13 Λειτουργία του ΜΕΤΡΟ το ΣΑΒΒΑΤΟ 19-1-2013. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.13 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ την ΠΑΡΑΣΚΕΥΗ 18-1-2013 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.01.13 Λειτουργία ΜΕΤΡΟ την Πέμπτη 17 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.01.13 Προβλήματα στα δρομολόγια λεωφορειακών γραμμών λόγω παγετού (06:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.13 Προβλήματα στα δρομολόγια λεωφορειακών γραμμών λόγω χιονόπτωσης (13:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.13 Προβλήματα στα δρομολόγια λεωφορειακών γραμμών λόγω χιονόπτωσης (11:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.13 Προβλήματα εκτέλεσης δρομολογίων λόγω χιονόπτωσης (07:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.12.12 Ωράριο λειτουργίας ΜΜΜ την παραμονή της Πρωτοχρονιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.12.12 Σταθερές συγκοινωνίες (ΣΤΑΣΥ): Δρομολόγια και συχνότητες κατά την περίοδο των εορτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>




<li class="collection-item"><a>9.12.12 Νέο δρομολόγιο της λεωφορειακής γραμμής 509 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.12.12 Συμμετοχή ΜΜΜ στις απεργιακές κινητοποιήσεις της 19ης - 20ης Δεκεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.12 Αναστολή λειτουργίας λεωφορειακής γραμμής 624 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.12.12 Κλειστοί σταθμοί του ΜΕΤΡΟ από 10:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.11.12 Τροποποίηση λεωφορειακής γραμμής 719 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.11.12 Απεργιακές κινητοποιήσεις των εργαζομένων στα  Μέσα Μαζικής Μεταφοράς αρμοδιότητας Ο.Α.Σ.Α. - Αιτήματα Αποζημιώσεως επιβατών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.11.12 Λειτουργία ΜΜΜ την Παρασκευή 9-11-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.11.12 Λειτουργία ΜΜΜ την Πέμπτη 8 Νοεμβρίου 2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.11.12 Λειτουργία ΜΜΜ από Δευτέρα 5-11-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.11.12 Λειτουργία των ΜΕΣΩΝ ΣΤΑΘΕΡΗΣ ΤΡΟΧΙΑΣ την ΠΑΡΑΣΚΕΥΗ 2-11-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.11.12 Σημαντική ειδοποίηση! Δρομολόγια γραμμής τρόλλεϋ 21 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.10.12 ΠΡΟΣΚΛΗΣΗ ΕΚΔΗΛΩΣΗΣ ΕΝΔΙΑΦΕΡΟΝΤΟΣ ΓΙΑ ΔΙΑΦΗΜΙΣΗ ΣΤΑ ΕΙΣΙΤΗΡΙΑ ΤΟΥ ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.10.12 Απεργιακές κινητοποιήσεις  στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.10.12 Στάση εργασίας σε Ηλεκτρικό και Μετρό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.10.12 Απεργιακές κινητοποιήσεις και ρυθμίσεις στα ΜΜΜ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.10.12 Κλειστοί οι σταθμοί του ΜΕΤΡΟ σε Σύνταγμα και Ευαγγελισμό </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.10.12 Τετάρτη 3 Οκτωβρίου: Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.09.12 Αποτελέσματα Κλήρωσης Εισιτηρίων 2012 και Οδηγίες για την παραλαβή των δώρων από τους δικαιούχους της Κλήρωσης </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>5.09.12 Αναβολή της κλήρωσης του ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.09.12 Λειτουργία ΜΜΜ κατά την διάρκεια της απεργίας της Τετάρτης 26 Σεπτεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.09.12 Πέμπτη 20 Σεπτεμβρίου: 24ωρη απεργία στα Μέσα Σταθερής Τροχιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.09.12 Νέα δρομολόγια στα ΜΜΜ από την Δευτέρα 10-09-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.08.12 Στάση εργασίας στο ΜΕΤΡΟ το Σάββατο 01-09-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.08.12 Αλλαγή δρομολογίων γραμμής Ε22  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.07.12 Νέα δρομολόγια για τον μήνα Αύγουστο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.07.12 Έκτακτο: Στάση εργασίας σε Μετρό και Ηλεκτρικό την Τρίτη 24 Ιουλίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.07.12 Τρίτη 17 Ιουλίου: Στάση εργασίας εργαζομένων στους πρώην ΗΣΑΠ (Γραμμή μετρό 1) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.06.12 Θερινό πρόγραμμα ΣΤΑ.ΣΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.06.12 Λειτουργία ΜΜΜ κατά την περίοδο των εκλογών της 17ης Ιουνίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.06.12 Δρομολόγια ΜΜΜ την Δευτέρα 4 Ιουνίου (Αγ. Πνεύματος) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.05.12 ΔΙΑΘΕΣΗ ΕΙΣΙΤΗΡΙΩΝ ΑΠΟ ΣΟΥΠΕΡ ΜΑΡΚΕΤ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.05.12 Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.05.12 Στάσεις εργασίας στα μέσα σταθερής τροχιάς Τρίτη 15 Μαϊου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.12 Στάσεις εργασίας στα ΜΜΜ λόγω εορτής της Πρωτομαγιάς </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.03.12 Στάση εργασίας στις Σταθερές Συγκοινωνίες (ΣΤΑ.ΣΥ.) την Τετάρτη 28 Μαρτίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.03.12 ΑΝΑΣΤΟΛΗ ΒΡΑΔΙΝΩΝ ΔΡΟΜΟΛΟΓΙΩΝ ΠΡΟΑΣΤΙΑΚΟΥ ΑΠΟ ΚΑΙ ΠΡΟΣ ΤΟ ΑΕΡΟΔΡΟΜΙΟ - ΚΑΝΟΝΙΚΑ ΤΟ ΜΕΤΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.03.12 Προσωρινά στοιχεία πωλήσεων κομίστρου έτους 2011 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.12 24ωρη απεργία των ηλεκτροδηγών στα Μέσα Σταθερής Τροχιάς (ΣΤΑ.ΣΥ.) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.12 Κλειστοί σταθμοί ΜΕΤΡΟ από 16:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.12 Στάση εργασίας στα Μπλέ λεωφορεία την Τρίτη 21-02-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.02.12 Συμμετοχή ΜΜΜ στην 48ωρη απεργία ΓΣΕΕ-ΑΔΕΔΥ της 10ης Φεβρουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.02.12 Συμμετοχή ΜΜΜ στην απεργία της 7-2-2012 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.01.12 Συμμετοχή των Εργαζομένων στα ΜΜΜ στην Παναττική απεργία της Τρίτης 17 Ιανουαρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.12.11 ΣΕ ΠΛΗΡΗ ΛΕΙΤΟΥΡΓΙΑ Η ΓΡΑΜΜΗ 1 ΤΟΥ ΜΕΤΡΟ (ΗΣΑΠ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>0.11.11 Συμμετοχή ΜΜΜ στις απεργιακές κινητοποιήσεις της 1ης Δεκεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>5.11.11 Στάσεις εργασίας στη ΣΤΑ.ΣΥ το Σ-Κ 26 - 27 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.11.11 Τρίτη 22 Νοεμβρίου, στάση εργασίας σε Μετρό, Ηλεκτρικό σιδηρόδρομο και Τραμ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.11.11 Βελτίωση διαδικασίας έκδοσης μηνιαίων καρτών απεριορίστων διαδρομών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.11.11 Ο ΟΑΣΑ και το ΚΑΠΕ συνεργάζονται για την εφαρμογή του ευρωπαϊκού έργου ENERQI, με σκοπό τη βελτίωση της ποιότητας υπηρεσιών των ΜΜΜ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.11.11 Στάσεις εργασίας σε λεωφορεία και τρόλλεϋ την Τετάρτη 2 Νοεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.10.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ την Τρίτη 25 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.10.11 ΛΕΙΤΟΥΡΓΙΑ ΜΕΣΩΝ ΜΑΖΙΚΗΣ ΜΕΤΑΦΟΡΑΣ ΤΗΝ ΤΕΤΑΡΤΗ 19 ΚΑΙ ΤΗΝ ΠΕΜΠΤΗ 20 ΟΚΤΩΒΡΙΟΥ (renew 16:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>8.10.11 ΛΕΙΤΟΥΡΓΙΑ ΜΕΣΩΝ ΜΑΖΙΚΗΣ ΜΕΤΑΦΟΡΑΣ ΤΗΝ ΤΕΤΑΡΤΗ 19 ΚΑΙ ΤΗΝ  ΠΕΜΠΤΗ 20 ΟΚΤΩΒΡΙΟΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.10.11 Απεργιακές κινητοποιήσεις Πέμπτη 13 και Παρασκευή 14 Oκτωβρίου 2011 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>7.10.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ την Δευτέρα 10 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.10.11 Στάση εργασίας στα λεωφορεία τη Δευτέρα 3 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.10.11 Στάση εργασίας στα Λεωφορεία την Δευτέρα 3 Οκτωβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.09.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ τη Τετάρτη 28 Σεπτεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.09.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ (Τρίτη και Τετάρτη) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.09.11 Απεργιακές κινητοποιήσεις στα  ΜΜΜ τη Δευτέρα 26 Σεπτεμβρίου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.09.11 24 ωρη απεργία σε Μετρό, Ηλεκτρικό και Τραμ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.09.11 Πέμπτη 22 Σεπτεμβρίου: 24ωρη απεργία στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>1.09.11 Νέα δρομολόγια ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.09.11 Διακοπή δρομολογίων στον Ηλεκτρικό σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.09.11 Σταση εργασιας σε ΜΕΤΡΟ - ΗΛΕΚΤΡΙΚΟ την Τεταρτη 7 Σεπτεμβριου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.09.11 Τεχνικό πρόβλημα στις γραμμές του ΜΕΤΡΟ και αδυναμία προσέγγισης στο αεροδρόμιο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>1.09.11 Παρασκευή 2 Σεπτεμβρίου: Απεργιακές κινητοποιήσεις στη ΣΤΑ.ΣΥ (Ηλεκτρικός σιδηρόδρομος, Μετρό, Τραμ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.09.11 Από Δευτέρα 5-9 μεταβολή στο σταθμό “Μοναστηράκι” του ΗΣΑΠ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.08.11 Νέα δρομολογια απο τον ΟΑΣΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>9.07.11 Επέκταση λεωφορεικών γραμμών Χ93 και Χ95 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.07.11 Αντιμετώπιση Φαινομένου Διακίνησης Πλαστών Εισιτηρίων Στις Αστικές Συγκοινωνίες </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.07.11 Διακοπή δρομολογίων ηλεκτρικού σιδηρόδρομου στο τμήμα ΠΕΙΡΑΙΑ - ΟΜΟΝΟΙΑ λόγω έργων (ΝΕΟ) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>2.07.11 Αναστολή λειτουργίας Λεωφορειακών γραμμών που εξυπηρετούν τα Πανεπιστημιακά ιδρύματα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.06.11 28 και 29 Ιουνίου Το ΜΕΤΡΟ λειτουργεί κανονικά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.06.11 28 και 29 Ιουνίου Το ΜΕΤΡΟ λειτουργεί κανονικά </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.06.11 ΜΕΤΑΘΕΣΗ ΗΜΕΡΟΜΗΝΙΑΣ ΔΙΕΝΕΡΓΕΙΑΣ ΔΙΑΓΩΝΙΣΜΟΥ - Αυτόματου Συστήματος Συλλογής Κομίστρου </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.06.11 Δευτέρα 6 Ιουνίου: Στάση εργασίας στο ΜΕΤΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.06.11 Παρασκευή 3 Ιουνίου: 24ωρη απεργία στον ηλεκτρικό σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>6.05.11 Σταση εργασίας στον ΗΣΑΠ την Τρίτη 17-5-2011 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.05.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ για Τρίτη - Τετάρτη (10052011_11:15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>





<li class="collection-item"><a>4.05.11 Πέμπτη 05-05-2011: Στάση εργασίας εργαζομένων στον ηλεκτρικό σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.04.11 Ωράριο λειτουργίας των Μέσων Μαζικής Μεταφοράς κατά τις αργίες του Πάσχα  (22,23,24,25 και 26 Απριλίου 2011) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.04.11 X8: Λεωφ. γραμμή εξυπηρέτησης για το τμήμα του ηλεκτρικού σιδηροδρόμου Αττική - Άνω Πατήσια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.03.11 Παράταση ανταλλαγής παλαιών εισιτηρίων </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.03.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ (13:45) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.03.11 Στάση εργασίας στα τρόλλεϋ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.03.11 Υλοποίηση Αυτόματου Συστήματος Συλλογής Κομίστρου για τις Αστικές Συγκοινωνίες της Αθήνας μέσω ΣΔΙΤ – Δημόσια Διαβούλευση </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για Δευτέρα 28-02 (06:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>5.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για Παρασκευή 25-02 (06:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>4.02.11 Ανταλλαγή εισιτηρίων (Νέο) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.02.11 Απεργιακές κινητοποιήσεις για ΤΕΤΑΡΤΗ 23-02-2011 (18:45) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για ΤΡΙΤΗ  22-02 (21:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για Δευτέρα 21-02 (19:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>7.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για Παρασκευή 18-02 (21:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.11 Απεργιακές κινητοποιήσεις ΜΜΜ για Παρασκευή 18-02 (renew 11:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.02.11 Eκδοτήρια ΗΣΑΠ για την ανταλλαγή παλαιών εισιτηρίων με νέα </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.02.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ (07:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ τη ΤΡΙΤΗ 15-02-2011 (14:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ (07:15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.02.11 Ισχύς – ανταλλαγή παλαιών εισιτηριών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.11 Στάσεις εργασίας στα ΜΜΜ για Παρασκευή 11-02-2011 (Ενημ.: 14:15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.02.11 Στάσεις εργασίας στα ΜΜΜ για Παρασκευή 11-02-2011 (Ενημ.: 14:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Στάση εργασίας στα ΜΜΜ για Τετάρτη 09-02-2011 (19:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Στάση εργασίας στα ΜΜΜ για Τετάρτη 09-02-2011 (13:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Στάση εργασίας στα ΜΜΜ για Τετάρτη 09-02-2011 (10:35) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Στάση εργασίας στα ΜΜΜ για Τετάρτη 09-02-2011 (08:35) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.02.11 Τελευταία δρομολόγια ΗΣΑΠ πριν τη στάση εργασίας 11:00 - 15:00 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.11 Απεργιακές Κινητοποιήσεις Tρίτη 8 Φεβρουαρίου 2011  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.02.11 Στάση εργασίας στην ΕΘΕΛ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.11 Υλοποίηση Ολοκληρωμένου Συστήματος Τηλεματικής για λεωφορεία και τρόλεϊ μέσω ΣΔΙΤ – Δημόσια Διαβούλευση </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.02.11 Απεργιακές Κινητοποιήσεις Παρασκευή 4 Φεβρουαρίου 2011 (ενημέρωση 6.55) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.02.11 Απεργιακές Κινητοποιήσεις Παρασκευή 4 Φεβρουαρίου 2011 (ενημέρωση 9.55) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>2.02.11 Απεργιακές Κινητοποιήσεις 2,3 - 5 Φεβρουαρίου 2011 (ενημέρωση 15.15) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>1.02.11 Νέες απεργιακές κινητοποιήσεις στα ΜΜΜ (Update3, 19:30) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>1.01.11 Νέες απεργιακές κινητοποιήσεις στα ΜΜΜ (Update2, 20:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.01.11 Νέες απεργιακές κινητοποιήσεις στα ΜΜΜ (Update1, 18:00) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>1.01.11 Νέες απεργιακές κινητοποιήσεις στα ΜΜΜ (Update) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.11 Νέες απεργιακές κινητοποιήσεις στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>6.01.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ από 25-01 - 28-01-2011 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>4.01.11 Στάση εργασίας ΕΘΕΛ  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>



<li class="collection-item"><a>1.01.11 Αναλυτικά οι νέες τιμές εισιτηρίων και καρτών </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.11 Καθορισμός Κομίστρων ΕΘΕΛ, ΗΣΑΠ, ΗΛΠΑΠ, ΑΜΕΛ, ΤΡΑΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.01.11 Επαναλειτουργία του Ηλεκτρικού Σιδηρόδρομου στο τμήμα ΕΙΡΗΝΗ-ΚΗΦΙΣΙΑ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>9.01.11 48ωρη Απεργία στον Προαστιακό Σιδηρόδρομο </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>8.01.11 Εξαγγελίες Στάσεων Εργασίας στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>












<li class="collection-item"><a>1.01.11 Απεργιακές κινητοποιήσεις στα ΜΜΜ τη Τρίτη(11-01), Τετάρτη(12-01) και Πέμπτη(13-01) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>


<li class="collection-item"><a>3.01.11 ΑΠΕΡΓΙΕΣ 2010 (Συγκεντρωτικά Δ.Τ για το δίμηνο Νοεμβρίου - Δεκεμβρίου 2010) </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>0.12.10 Tην Παρασκευή 31-12-2010, Παραμονή Πρωτοχρονιάς, τα Αστικά Μέσα Μεταφοράς θα αποσύρονται σταδιακά από την κυκλοφορία από τις 22:30. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.12.10 Απεργιακές κινητοποιήσεις ΜΜΜ τη Δευτέρα 20-12-2010 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>7.12.10 Τροποποιήσεις σε δρομολόγια του ΜΕΤΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.10 Απεργιακές κινητοποιήσεις στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>4.12.10 Απεργιακές κινητοποιήσεις στα ΜΜΜ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.12.10 24ωρη απεργία στα ΜΜΜ τη ΤΡΙΤΗ 14-12-2010. Προαστιακός στάση εργασίας από 12:00 - 15:00  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>3.12.10 Στάση εργασίας σε όλα τα ΜΜΜ την ΔΕΥΤΕΡΑ 13-12-2010 από 11:00 - 17:00  </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>.05.10 Δρομολόγηση λεωφ. Χ6 ΤΑΥΡΟΣ - ΦΑΛΗΡΟ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>.04.10 ΑΠΕΡΓΙΑΚΕΣ ΚΙΝΗΤΟΠΟΙΗΣΕΙΣ ΤΗΝ 1η ΜΑΙΟΥ </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>.04.10 Σας πάμε για. . .  δενδροφύτευση και στις 11/04/2010 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>.03.10 Κατάργηση λεωφ. γραμμών 601 - 603 </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>

<li class="collection-item"><a>09.10 Χειμερινά Δρομολόγια </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>
</ul>