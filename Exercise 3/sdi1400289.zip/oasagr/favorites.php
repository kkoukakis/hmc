
<?php 
//HEADER
include('./components/header/header.php');
?>


<?php
// BREADCRUMB
$breadcrumb = array('Oasa.gr','Αγαπημένα μου');
$breadlinks = array('index.php','favorites.php');
include('components\breadcrumbs\breadcrumb.php');
?>



<ul class="collection" style="background-color: whitesmoke;">


<?php 

//SQL request to show data


echo('<li class="collection-item"><a>14.01.20 Μερική προσωρινή τροποποίηση της λεωφορειακής γραμμής 101 λόγω έργων στο Δήμο Αλίμου. </a><a href="#!" class="secondary-content"><i class="material-icons"><3</i></a></div></li>');

?>

</ul>